from __future__ import annotations

from dataclasses import dataclass
from typing import Callable, Optional

from fastapi import Depends, HTTPException, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer

from backend.config import firebase_auth, db

bearer = HTTPBearer(auto_error=False)


@dataclass
class CurrentUser:
    uid: str
    role: str = "student"
    email: Optional[str] = None


def _decode_token(token: str) -> dict:
    try:
        return firebase_auth.verify_id_token(token) if firebase_auth else {"uid": "demo", "email": "demo@school.test"}
    except Exception as exc:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Token inválido") from exc


def get_current_user(
    credentials: HTTPAuthorizationCredentials | None = Depends(bearer),
) -> CurrentUser:
    if credentials is None:
        return CurrentUser(uid="demo", role="student", email="demo@school.test")

    decoded = _decode_token(credentials.credentials)
    uid = decoded.get("uid") or decoded.get("user_id") or decoded.get("sub") or "demo"
    role = decoded.get("role") or "student"
    email = decoded.get("email")
    if db is not None:
        try:
            snap = db.collection("users").document(uid).get()
            if snap.exists:
                data = snap.to_dict() or {}
                role = data.get("role", role)
                email = data.get("email", email)
        except Exception:
            pass
    return CurrentUser(uid=uid, role=role, email=email)


def require_role(*allowed_roles: str) -> Callable:
    def _dep(user: CurrentUser = Depends(get_current_user)) -> CurrentUser:
        if allowed_roles and user.role not in allowed_roles:
            raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Permisos insuficientes")
        return user
    return _dep


def set_user_role_claim(uid: str, role: str) -> None:
    if firebase_auth is None:
        return
    firebase_auth.set_custom_user_claims(uid, {"role": role})
