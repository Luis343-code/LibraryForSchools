from __future__ import annotations

import os
from functools import lru_cache
from pathlib import Path
from typing import Optional

import firebase_admin
from dotenv import load_dotenv
from firebase_admin import credentials, firestore, auth as firebase_auth
from pydantic_settings import BaseSettings, SettingsConfigDict

load_dotenv()


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    firebase_service_account_path: str = os.getenv(
        "FIREBASE_SERVICE_ACCOUNT_PATH", "./firebase/serviceAccountKey.json"
    )
    firebase_project_id: str = os.getenv(
        "FIREBASE_PROJECT_ID", "libraryforschools-93177"
    )
    firebase_storage_bucket: str = os.getenv(
        "FIREBASE_STORAGE_BUCKET", "libraryforschools-93177.firebasestorage.app"
    )
    firebase_database_url: Optional[str] = os.getenv("FIREBASE_DATABASE_URL")


@lru_cache
def get_settings() -> Settings:
    return Settings()


def init_firebase():
    settings = get_settings()

    BASE_DIR = Path(__file__).resolve().parent.parent
    service_account_path = BASE_DIR / "firebase" / "serviceAccountKey.json"

    if not service_account_path.exists():
        raise FileNotFoundError(
            f"No se encontró el serviceAccountKey.json en: {service_account_path}"
        )

    if not firebase_admin._apps:
        firebase_admin.initialize_app(
            credentials.Certificate(str(service_account_path)),
            {
                "projectId": settings.firebase_project_id,
                "storageBucket": settings.firebase_storage_bucket,
                **(
                    {"databaseURL": settings.firebase_database_url}
                    if settings.firebase_database_url
                    else {}
                ),
            },
        )

    return firestore.client()


# 🔥 Esto inicializa Firebase UNA sola vez
db = init_firebase()