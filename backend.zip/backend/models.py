from __future__ import annotations

from datetime import datetime
from typing import Literal, Optional

from pydantic import BaseModel, Field


Role = Literal["student", "librarian", "admin"]
BookType = Literal["physical", "digital", "both"]
LoanStatus = Literal["pending", "active", "denied", "returned", "overdue"]


class UserProfile(BaseModel):
    uid: str
    name: str
    email: str
    role: Role = "student"
    avatar_url: Optional[str] = None
    created_at: datetime = Field(default_factory=datetime.utcnow)


class UserProfileUpdate(BaseModel):
    name: Optional[str] = None
    avatar_url: Optional[str] = None


class BookBase(BaseModel):
    title: str
    author: str
    publisher: str
    year: int
    category: str
    synopsis: str
    cover_color: str = "#1E3A8A"
    book_type: BookType = "both"
    total_copies: int = 1
    available_copies: int = 1
    digital_price: float = 0.0
    rating: float = 4.5
    tags: list[str] = Field(default_factory=list)


class BookCreate(BookBase):
    pass


class BookUpdate(BaseModel):
    title: Optional[str] = None
    author: Optional[str] = None
    publisher: Optional[str] = None
    year: Optional[int] = None
    category: Optional[str] = None
    synopsis: Optional[str] = None
    cover_color: Optional[str] = None
    book_type: Optional[BookType] = None
    total_copies: Optional[int] = None
    available_copies: Optional[int] = None
    digital_price: Optional[float] = None
    rating: Optional[float] = None
    tags: Optional[list[str]] = None


class Book(BookBase):
    id: str
    cover_url: Optional[str] = None
    created_at: datetime = Field(default_factory=datetime.utcnow)


class LoanCreate(BaseModel):
    book_id: str
    user_id: str
    days: int = 21


class LoanUpdate(BaseModel):
    status: LoanStatus
    notes: Optional[str] = None


class Loan(BaseModel):
    id: str
    book_id: str
    user_id: str
    requested_at: datetime = Field(default_factory=datetime.utcnow)
    due_date: datetime
    returned_at: Optional[datetime] = None
    status: LoanStatus = "pending"
    notes: Optional[str] = None


class CommunityPostCreate(BaseModel):
    content: str
    book_id: Optional[str] = None


class CommunityPost(BaseModel):
    id: str
    user_id: str
    content: str
    book_id: Optional[str] = None
    user_name: Optional[str] = None
    user_avatar_initial: Optional[str] = None
    book_title: Optional[str] = None
    likes: int = 0
    comments_count: int = 0
    created_at: datetime = Field(default_factory=datetime.utcnow)


class CommentCreate(BaseModel):
    content: str


class SystemSettings(BaseModel):
    library_name: str = "La Biblioteca de los Ecos"
    loan_days: int = 21
    max_loans_per_user: int = 3
    late_fee_policy: str = "1 dia de espera por dia de retraso"
    due_soon_days: int = 5
    updated_at: datetime = Field(default_factory=datetime.utcnow)


class PurchaseCreate(BaseModel):
    user_id: str
    book_id: str
    payment_ref: Optional[str] = None


class Purchase(BaseModel):
    id: str
    user_id: str
    book_id: str
    book_title: Optional[str] = None
    payment_ref: Optional[str] = None
    created_at: datetime = Field(default_factory=datetime.utcnow)
