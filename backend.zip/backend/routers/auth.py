from __future__ import annotations

from datetime import datetime
from fastapi import APIRouter, Depends, HTTPException

from backend.middleware.auth import CurrentUser, get_current_user, set_user_role_claim
from backend.config import db, firebase_auth
from backend.models import UserProfile, UserProfileUpdate

router = APIRouter(prefix="/auth", tags=["auth"])


def _doc_to_user(doc: dict, doc_id: str) -> UserProfile:
    data = doc.copy()
    data["uid"] = doc_id
    if "created_at" in data and isinstance(data["created_at"], datetime):
        data["created_at"] = data["created_at"].isoformat()
    return UserProfile(**data)


@router.post("/register")
def register(user_data: UserProfile):
    if db is None or firebase_auth is None:
        raise HTTPException(status_code=503, detail="Firebase no configurado")
    
    try:
        user_ref = db.collection("users").document(user_data.uid)
        if user_ref.get().exists:
            raise HTTPException(status_code=400, detail="Usuario ya existe")
        
        user_ref.set({
            "name": user_data.name,
            "email": user_data.email,
            "role": user_data.role,
            "avatar_url": user_data.avatar_url,
            "created_at": datetime.utcnow()
        })
        set_user_role_claim(user_data.uid, user_data.role)
        
        return {"uid": user_data.uid, "message": "Usuario registrado"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/me")
def me(user: CurrentUser = Depends(get_current_user)):
    if db is None:
        return {"uid": user.uid, "role": user.role, "email": user.email, "name": "Usuario demo"}
    
    doc = db.collection("users").document(user.uid).get()
    if not doc.exists:
        return {"uid": user.uid, "role": user.role, "email": user.email, "name": "Usuario"}
    
    return _doc_to_user(doc.to_dict(), doc.id)


@router.patch("/me")
def update_me(user_data: UserProfileUpdate, user: CurrentUser = Depends(get_current_user)):
    if db is None:
        raise HTTPException(status_code=503, detail="Firebase no configurado")
    
    user_ref = db.collection("users").document(user.uid)
    if not user_ref.get().exists:
        raise HTTPException(status_code=404, detail="Perfil no encontrado")
    
    update_data = user_data.model_dump()
    update_data = {k: v for k, v in update_data.items() if v is not None}
    
    user_ref.update(update_data)
    
    updated = user_ref.get()
    return _doc_to_user(updated.to_dict(), user.uid)


@router.post("/logout")
def logout(user: CurrentUser = Depends(get_current_user)):
    return {"message": "Sesión cerrada", "uid": user.uid}
