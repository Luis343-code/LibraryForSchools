from __future__ import annotations

from datetime import datetime
from uuid import uuid4
from fastapi import APIRouter, Depends, HTTPException, Query
from backend.middleware.auth import CurrentUser, require_role
from backend.config import db
from backend.models import Book, BookCreate, BookUpdate

router = APIRouter(prefix="/books", tags=["books"])

SAMPLE_CATEGORIES = ["Fantasía", "Aventura", "Historia", "Ciencia", "Distopía", "Clásicos"]


def _doc_to_book(doc: dict, doc_id: str) -> Book:
    data = doc.copy()
    data["id"] = doc_id
    if "created_at" in data and isinstance(data["created_at"], datetime):
        data["created_at"] = data["created_at"].isoformat()
    return Book(**data)


@router.get("/")
def list_books(
    search: str | None = Query(default=None),
    category: str | None = Query(default=None),
    available: bool | None = Query(default=None),
    book_type: str | None = Query(default=None),
):
    if db is None:
        return {"items": [], "total": 0, "filters": {"search": search, "category": category, "available": available, "book_type": book_type}}
    
    ref = db.collection("books")
    conditions = []
    
    normalized_search = search.lower().strip() if search else None
    if category:
        conditions.append(("category", "==", category))
    if book_type:
        conditions.append(("book_type", "==", book_type))
    
    query = ref
    for field, op, value in conditions:
        query = query.where(field, op, value)
    
    docs = query.stream()
    items = []
    for doc in docs:
        data = doc.to_dict()
        if normalized_search:
            haystack = " ".join(
                [
                    str(data.get("title", "")),
                    str(data.get("author", "")),
                    str(data.get("publisher", "")),
                    str(data.get("category", "")),
                    str(data.get("synopsis", "")),
                ]
            ).lower()
            if normalized_search not in haystack:
                continue
        if available is not None:
            avail = data.get("available_copies", 0) > 0
            if available != avail:
                continue
        items.append(_doc_to_book(data, doc.id))

    items.sort(key=lambda book: book.title.lower())
    
    return {
        "items": [b.model_dump() for b in items],
        "total": len(items),
        "filters": {"search": search, "category": category, "available": available, "book_type": book_type}
    }


@router.get("/meta/categories")
def categories():
    if db is None:
        return {"items": SAMPLE_CATEGORIES}

    docs = db.collection("books").stream()
    items = sorted({(doc.to_dict() or {}).get("category") for doc in docs if (doc.to_dict() or {}).get("category")})
    if not items:
        items = SAMPLE_CATEGORIES
    return {"items": items}


@router.post("/", dependencies=[Depends(require_role("librarian", "admin"))])
def create_book(book: BookCreate):
    if db is None:
        raise HTTPException(status_code=503, detail="Firebase no configurado")
    
    book_id = str(uuid4())
    book_data = book.model_dump()
    book_data["created_at"] = datetime.utcnow()
    book_data["available_copies"] = min(book_data["available_copies"], book_data["total_copies"])
    
    db.collection("books").document(book_id).set(book_data)
    
    return {"id": book_id, **book_data}


@router.get("/{book_id}")
def get_book(book_id: str):
    if db is None:
        raise HTTPException(status_code=503, detail="Firebase no configurado")
    
    doc = db.collection("books").document(book_id).get()
    if not doc.exists:
        raise HTTPException(status_code=404, detail="Libro no encontrado")
    
    return _doc_to_book(doc.to_dict(), doc.id)


@router.patch("/{book_id}", dependencies=[Depends(require_role("librarian", "admin"))])
def update_book(book_id: str, book: BookUpdate):
    if db is None:
        raise HTTPException(status_code=503, detail="Firebase no configurado")
    
    doc_ref = db.collection("books").document(book_id)
    doc = doc_ref.get()
    if not doc.exists:
        raise HTTPException(status_code=404, detail="Libro no encontrado")
    
    update_data = {k: v for k, v in book.model_dump().items() if v is not None}
    if "total_copies" in update_data and "available_copies" in update_data:
        update_data["available_copies"] = min(update_data["available_copies"], update_data["total_copies"])
    elif "total_copies" in update_data:
        current_available = (doc.to_dict() or {}).get("available_copies", 0)
        update_data["available_copies"] = min(current_available, update_data["total_copies"])
    if update_data:
        doc_ref.update(update_data)
    
    updated = doc_ref.get()
    return _doc_to_book(updated.to_dict(), book_id)


@router.delete("/{book_id}", dependencies=[Depends(require_role("librarian", "admin"))])
def delete_book(book_id: str):
    if db is None:
        raise HTTPException(status_code=503, detail="Firebase no configurado")
    
    doc_ref = db.collection("books").document(book_id)
    doc = doc_ref.get()
    if not doc.exists:
        raise HTTPException(status_code=404, detail="Libro no encontrado")
    
    doc_ref.delete()
    return {"id": book_id, "message": "Libro eliminado"}

@router.post("/{book_id}/cover", dependencies=[Depends(require_role("librarian", "admin"))])
def upload_cover(book_id: str):
    return {"id": book_id, "message": "Implementar con Firebase Storage"}
