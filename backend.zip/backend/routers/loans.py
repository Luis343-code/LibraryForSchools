from __future__ import annotations

from datetime import datetime, timedelta
from uuid import uuid4
from fastapi import APIRouter, Depends, HTTPException, Query

from backend.middleware.auth import CurrentUser, require_role
from backend.config import db
from backend.models import Loan, LoanCreate, LoanUpdate

router = APIRouter(prefix="/loans", tags=["loans"])


def _doc_to_loan(doc: dict, doc_id: str) -> Loan:
    data = doc.copy()
    data["id"] = doc_id
    for f in ["requested_at", "due_date", "returned_at"]:
        if f in data and isinstance(data[f], datetime):
            data[f] = data[f].isoformat()
    return Loan(**data)


def _loan_payload(doc: dict, doc_id: str) -> dict:
    loan = _doc_to_loan(doc, doc_id).model_dump()
    if db is None:
        return loan

    book_doc = db.collection("books").document(doc.get("book_id", "")).get()
    if book_doc.exists:
        book = book_doc.to_dict() or {}
        loan["book_title"] = book.get("title")
        loan["book_author"] = book.get("author")

    user_doc = db.collection("users").document(doc.get("user_id", "")).get()
    if user_doc.exists:
        user_data = user_doc.to_dict() or {}
        loan["user_name"] = user_data.get("name")

    return loan


@router.get("/")
def list_loans(
    status: str | None = Query(default=None),
    user: CurrentUser = Depends(require_role("student", "librarian", "admin"))
):
    if db is None:
        return {"items": [], "status": status, "viewer": user.role}
    
    ref = db.collection("loans")
    
    if user.role == "student":
        docs = ref.where("user_id", "==", user.uid).stream()
    else:
        docs = ref.stream()
    
    items = []
    for doc in docs:
        data = doc.to_dict()
        if status and data.get("status") != status:
            continue
        items.append(_loan_payload(data, doc.id))

    return {
        "items": items,
        "status": status,
        "viewer": user.role
    }


@router.post("/")
def create_loan(
    loan: LoanCreate,
    user: CurrentUser = Depends(require_role("student", "librarian", "admin"))
):
    if db is None:
        raise HTTPException(status_code=503, detail="Firebase no configurado")
    
    book_ref = db.collection("books").document(loan.book_id)
    book_doc = book_ref.get()
    if not book_doc.exists:
        raise HTTPException(status_code=404, detail="Libro no encontrado")
    
    book_data = book_doc.to_dict()
    if book_data.get("available_copies", 0) <= 0:
        raise HTTPException(status_code=400, detail="No hay copias disponibles")

    borrower_uid = loan.user_id if user.role in ("librarian", "admin") else user.uid
    active_loans = [
        item.to_dict() or {}
        for item in db.collection("loans").where("user_id", "==", borrower_uid).stream()
    ]
    if any(item.get("book_id") == loan.book_id and item.get("status") in ("pending", "active", "overdue") for item in active_loans):
        raise HTTPException(status_code=400, detail="Ese usuario ya tiene una solicitud o prestamo para este libro")
    
    loan_id = str(uuid4())
    requested_at = datetime.utcnow()
    due_date = requested_at + timedelta(days=loan.days)
    
    loan_data = {
        "book_id": loan.book_id,
        "user_id": borrower_uid,
        "requested_at": requested_at,
        "due_date": due_date,
        "status": "pending",
    }
    
    db.collection("loans").document(loan_id).set(loan_data)
    
    return {"id": loan_id, **loan_data}


@router.patch("/{loan_id}")
def review_loan(
    loan_id: str,
    loan: LoanUpdate,
    user: CurrentUser = Depends(require_role("librarian", "admin"))
):
    if db is None:
        raise HTTPException(status_code=503, detail="Firebase no configurado")
    
    loan_ref = db.collection("loans").document(loan_id)
    loan_doc = loan_ref.get()
    if not loan_doc.exists:
        raise HTTPException(status_code=404, detail="Préstamo no encontrado")
    
    loan_data = loan_doc.to_dict()
    updates = {"status": loan.status}
    
    if loan.status == "active" and loan_data.get("status") == "pending":
        book_ref = db.collection("books").document(loan_data["book_id"])
        book_doc = book_ref.get()
        if book_doc.exists:
            book_data = book_doc.to_dict()
            new_available = (book_data.get("available_copies", 1) - 1)
            book_ref.update({"available_copies": max(0, new_available)})
    
    if loan.notes:
        updates["notes"] = loan.notes
    
    loan_ref.update(updates)
    
    updated = loan_ref.get()
    return _doc_to_loan(updated.to_dict(), loan_id)


@router.post("/{loan_id}/return")
def return_loan(
    loan_id: str,
    user: CurrentUser = Depends(require_role("librarian", "admin"))
):
    if db is None:
        raise HTTPException(status_code=503, detail="Firebase no configurado")
    
    loan_ref = db.collection("loans").document(loan_id)
    loan_doc = loan_ref.get()
    if not loan_doc.exists:
        raise HTTPException(status_code=404, detail="Préstamo no encontrado")
    
    loan_data = loan_doc.to_dict()
    if loan_data.get("status") == "returned":
        raise HTTPException(status_code=400, detail="Ya fue devuelto")
    
    returned_at = datetime.utcnow()
    loan_ref.update({
        "status": "returned",
        "returned_at": returned_at
    })
    
    book_ref = db.collection("books").document(loan_data["book_id"])
    book_doc = book_ref.get()
    if book_doc.exists:
        book_data = book_doc.to_dict()
        new_available = (book_data.get("available_copies", 0) + 1)
        book_ref.update({"available_copies": new_available})
    
    return {"id": loan_id, "returned_at": returned_at.isoformat(), "message": "Libro devuelto"}


@router.post("/check-overdue")
def check_overdue(user: CurrentUser = Depends(require_role("admin"))):
    if db is None:
        raise HTTPException(status_code=503, detail="Firebase no configurado")
    
    now = datetime.utcnow()
    docs = db.collection("loans").where("status", "==", "active").stream()
    
    updated_count = 0
    for doc in docs:
        data = doc.to_dict()
        due_date = data.get("due_date")
        if due_date and isinstance(due_date, datetime) and due_date < now:
            db.collection("loans").document(doc.id).update({"status": "overdue"})
            updated_count += 1
    
    return {
        "checked_at": now.isoformat(),
        "overdue_count": updated_count,
        "window": str(timedelta(days=1))
    }
