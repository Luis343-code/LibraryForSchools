from __future__ import annotations

from datetime import datetime
from uuid import uuid4

from fastapi import APIRouter, Depends, HTTPException, Query

from backend.config import db
from backend.middleware.auth import CurrentUser, get_current_user, require_role
from backend.models import CommentCreate, CommunityPost, CommunityPostCreate

router = APIRouter(prefix="/community", tags=["community"])
POSTS_COLLECTION = "community_posts"


def _user_public_profile(uid: str) -> dict:
    if db is None:
        return {"user_name": "Anonimo", "user_avatar_initial": "A"}
    user_doc = db.collection("users").document(uid).get()
    if user_doc.exists:
        data = user_doc.to_dict() or {}
        name = data.get("name") or "Anonimo"
        return {"user_name": name, "user_avatar_initial": name[:1].upper()}
    return {"user_name": "Anonimo", "user_avatar_initial": "A"}


def _book_title(book_id: str | None) -> str | None:
    if not book_id or db is None:
        return None
    book_doc = db.collection("books").document(book_id).get()
    if not book_doc.exists:
        return None
    return (book_doc.to_dict() or {}).get("title")


def _doc_to_post(doc: dict, doc_id: str) -> CommunityPost:
    data = doc.copy()
    data["id"] = doc_id
    for field in ("created_at", "updated_at"):
        if field in data and isinstance(data[field], datetime):
            data[field] = data[field].isoformat()
    return CommunityPost(**data)


@router.get("/posts")
def list_posts(book_tag: str | None = Query(default=None)):
    if db is None:
        return {"items": [], "book_tag": book_tag}

    docs = db.collection(POSTS_COLLECTION).order_by("created_at", direction="DESCENDING").stream()

    items = []
    for doc in docs:
        data = doc.to_dict() or {}
        if book_tag and data.get("book_id") != book_tag and data.get("book_title") != book_tag:
            continue
        items.append(_doc_to_post(data, doc.id))

    return {"items": [p.model_dump() for p in items], "book_tag": book_tag}


@router.post("/posts")
def create_post(
    post: CommunityPostCreate,
    user: CurrentUser = Depends(require_role("student", "librarian", "admin")),
):
    if db is None:
        raise HTTPException(status_code=503, detail="Firebase no configurado")

    post_id = str(uuid4())
    now = datetime.utcnow()
    post_data = {
        **post.model_dump(),
        **_user_public_profile(user.uid),
        "book_title": _book_title(post.book_id),
        "user_id": user.uid,
        "likes": 0,
        "comments_count": 0,
        "created_at": now,
        "updated_at": now,
    }

    db.collection(POSTS_COLLECTION).document(post_id).set(post_data)

    return {"id": post_id, **post_data}


@router.patch("/posts/{post_id}")
def update_post(
    post_id: str,
    post: CommunityPostCreate,
    user: CurrentUser = Depends(require_role("student", "librarian", "admin")),
):
    if db is None:
        raise HTTPException(status_code=503, detail="Firebase no configurado")

    post_ref = db.collection(POSTS_COLLECTION).document(post_id)
    doc = post_ref.get()
    if not doc.exists:
        raise HTTPException(status_code=404, detail="Publicacion no encontrada")

    data = doc.to_dict() or {}
    if data.get("user_id") != user.uid and user.role not in ("librarian", "admin"):
        raise HTTPException(status_code=403, detail="No autorizado")

    post_ref.update(
        {
            "content": post.content,
            "book_id": post.book_id,
            "book_title": _book_title(post.book_id),
            "updated_at": datetime.utcnow(),
        }
    )

    updated = post_ref.get()
    return _doc_to_post(updated.to_dict() or {}, post_id)


@router.delete("/posts/{post_id}")
def delete_post(
    post_id: str,
    user: CurrentUser = Depends(require_role("student", "librarian", "admin")),
):
    if db is None:
        raise HTTPException(status_code=503, detail="Firebase no configurado")

    post_ref = db.collection(POSTS_COLLECTION).document(post_id)
    doc = post_ref.get()
    if not doc.exists:
        raise HTTPException(status_code=404, detail="Publicacion no encontrada")

    data = doc.to_dict() or {}
    if data.get("user_id") != user.uid and user.role not in ("librarian", "admin"):
        raise HTTPException(status_code=403, detail="No autorizado")

    for like_doc in post_ref.collection("likes").stream():
        like_doc.reference.delete()
    for comment_doc in post_ref.collection("comments").stream():
        comment_doc.reference.delete()
    post_ref.delete()

    return {"id": post_id, "message": "Publicacion eliminada"}


@router.post("/posts/{post_id}/like")
def like_post(post_id: str, user: CurrentUser = Depends(get_current_user)):
    if db is None:
        raise HTTPException(status_code=503, detail="Firebase no configurado")

    post_ref = db.collection(POSTS_COLLECTION).document(post_id)
    doc = post_ref.get()
    if not doc.exists:
        raise HTTPException(status_code=404, detail="Publicacion no encontrada")

    data = doc.to_dict() or {}
    like_ref = post_ref.collection("likes").document(user.uid)
    like_doc = like_ref.get()

    if like_doc.exists:
        like_ref.delete()
        new_likes = max(0, (data.get("likes") or 0) - 1)
        liked = False
    else:
        like_ref.set({"post_id": post_id, "user_id": user.uid, "created_at": datetime.utcnow()})
        new_likes = (data.get("likes") or 0) + 1
        liked = True

    post_ref.update({"likes": new_likes})
    return {"id": post_id, "likes": new_likes, "liked": liked}


@router.get("/posts/{post_id}/comments")
def list_comments(post_id: str):
    if db is None:
        return {"post_id": post_id, "items": []}

    docs = (
        db.collection(POSTS_COLLECTION)
        .document(post_id)
        .collection("comments")
        .order_by("created_at")
        .stream()
    )

    items = []
    for doc in docs:
        data = doc.to_dict() or {}
        data["id"] = doc.id
        if "created_at" in data and isinstance(data["created_at"], datetime):
            data["created_at"] = data["created_at"].isoformat()
        items.append(data)

    return {"post_id": post_id, "items": items}


@router.post("/posts/{post_id}/comments")
def create_comment(
    post_id: str,
    comment: CommentCreate,
    user: CurrentUser = Depends(require_role("student", "librarian", "admin")),
):
    if db is None:
        raise HTTPException(status_code=503, detail="Firebase no configurado")

    post_ref = db.collection(POSTS_COLLECTION).document(post_id)
    post_doc = post_ref.get()
    if not post_doc.exists:
        raise HTTPException(status_code=404, detail="Publicacion no encontrada")

    comment_id = str(uuid4())
    now = datetime.utcnow()
    profile = _user_public_profile(user.uid)
    comment_data = {
        "post_id": post_id,
        "user_id": user.uid,
        "user_name": profile["user_name"],
        "user_avatar_initial": profile["user_avatar_initial"],
        "content": comment.content,
        "created_at": now,
    }

    post_ref.collection("comments").document(comment_id).set(comment_data)

    post_data = post_doc.to_dict() or {}
    post_ref.update({"comments_count": (post_data.get("comments_count") or 0) + 1})

    return {"post_id": post_id, "id": comment_id, "item": {**comment_data, "id": comment_id}}


@router.delete("/posts/{post_id}/comments/{cid}")
def delete_comment(
    post_id: str,
    cid: str,
    user: CurrentUser = Depends(require_role("student", "librarian", "admin")),
):
    if db is None:
        raise HTTPException(status_code=503, detail="Firebase no configurado")

    post_ref = db.collection(POSTS_COLLECTION).document(post_id)
    comment_ref = post_ref.collection("comments").document(cid)
    doc = comment_ref.get()
    if not doc.exists:
        raise HTTPException(status_code=404, detail="Comentario no encontrado")

    data = doc.to_dict() or {}
    if data.get("user_id") != user.uid and user.role not in ("librarian", "admin"):
        raise HTTPException(status_code=403, detail="No autorizado")

    comment_ref.delete()

    post_doc = post_ref.get()
    if post_doc.exists:
        post_data = post_doc.to_dict() or {}
        post_ref.update({"comments_count": max(0, (post_data.get("comments_count") or 0) - 1)})

    return {"post_id": post_id, "comment_id": cid, "message": "Comentario eliminado"}
