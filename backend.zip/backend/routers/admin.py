from __future__ import annotations

from datetime import datetime
from uuid import uuid4

from fastapi import APIRouter, Depends, HTTPException, Query

from backend.config import db
from backend.middleware.auth import CurrentUser, require_role, set_user_role_claim
from backend.models import Purchase, PurchaseCreate, SystemSettings

router = APIRouter(prefix="/admin", tags=["admin"])
SETTINGS_DOC = ("system", "settings")


def _doc_to_purchase(doc: dict, doc_id: str) -> Purchase:
    data = doc.copy()
    data["id"] = doc_id
    if "created_at" in data and isinstance(data["created_at"], datetime):
        data["created_at"] = data["created_at"].isoformat()
    return Purchase(**data)


def _settings_ref():
    return db.collection(SETTINGS_DOC[0]).document(SETTINGS_DOC[1])


@router.get("/stats")
def stats(user: CurrentUser = Depends(require_role("admin"))):
    if db is None:
        return {"books": 0, "loans": 0, "community_posts": 0, "purchases": 0, "users": 0}

    loans = [doc.to_dict() or {} for doc in db.collection("loans").stream()]
    stats = {
        "books": sum(1 for _ in db.collection("books").stream()),
        "loans": len(loans),
        "community_posts": sum(1 for _ in db.collection("community_posts").stream()),
        "purchases": sum(1 for _ in db.collection("purchases").stream()),
        "users": sum(1 for _ in db.collection("users").stream()),
        "active_loans": sum(1 for loan in loans if loan.get("status") == "active"),
        "pending_loans": sum(1 for loan in loans if loan.get("status") == "pending"),
        "overdue_loans": sum(1 for loan in loans if loan.get("status") == "overdue"),
    }

    return stats


@router.get("/users")
def list_users(role: str | None = Query(default=None), user: CurrentUser = Depends(require_role("admin"))):
    if db is None:
        return {"items": []}

    ref = db.collection("users")
    docs = ref.where("role", "==", role).stream() if role else ref.stream()

    items = []
    for doc in docs:
        data = doc.to_dict() or {}
        data["uid"] = doc.id
        data["loans_count"] = sum(
            1
            for loan in db.collection("loans").where("user_id", "==", doc.id).stream()
            if (loan.to_dict() or {}).get("status") in ("pending", "active", "overdue")
        )
        items.append(data)

    return {"items": items}


@router.patch("/users/{uid}")
def update_user(uid: str, data: dict, user: CurrentUser = Depends(require_role("admin"))):
    if db is None:
        raise HTTPException(status_code=503, detail="Firebase no configurado")

    user_ref = db.collection("users").document(uid)
    snapshot = user_ref.get()
    if not snapshot.exists:
        raise HTTPException(status_code=404, detail="Usuario no encontrado")

    update_data = {k: v for k, v in data.items() if v is not None}
    if "role" in update_data:
        set_user_role_claim(uid, update_data["role"])
    if update_data:
        user_ref.update(update_data)

    updated = user_ref.get()
    result = updated.to_dict() or {}
    result["uid"] = uid
    return result


@router.delete("/users/{uid}")
def delete_user(uid: str, user: CurrentUser = Depends(require_role("admin"))):
    if db is None:
        raise HTTPException(status_code=503, detail="Firebase no configurado")

    user_ref = db.collection("users").document(uid)
    if not user_ref.get().exists:
        raise HTTPException(status_code=404, detail="Usuario no encontrado")

    user_ref.delete()
    return {"uid": uid, "message": "Usuario eliminado"}


@router.post("/purchases")
def create_purchase(
    purchase: PurchaseCreate,
    user: CurrentUser = Depends(require_role("student", "librarian", "admin")),
):
    if db is None:
        raise HTTPException(status_code=503, detail="Firebase no configurado")

    book_ref = db.collection("books").document(purchase.book_id)
    book_doc = book_ref.get()
    if not book_doc.exists:
        raise HTTPException(status_code=404, detail="Libro no encontrado")

    book_data = book_doc.to_dict() or {}
    if book_data.get("book_type") == "physical":
        raise HTTPException(status_code=400, detail="Este libro no tiene compra digital")

    owner_uid = purchase.user_id if user.role == "admin" else user.uid
    purchase_id = str(uuid4())
    purchase_data = {
        "user_id": owner_uid,
        "book_id": purchase.book_id,
        "payment_ref": purchase.payment_ref,
        "created_at": datetime.utcnow(),
    }

    db.collection("purchases").document(purchase_id).set(purchase_data)

    return {"id": purchase_id, **purchase_data}


@router.get("/purchases/my")
def my_purchases(user: CurrentUser = Depends(require_role("student", "librarian", "admin"))):
    if db is None:
        return {"user_id": user.uid, "items": []}

    docs = db.collection("purchases").where("user_id", "==", user.uid).stream()

    items = []
    for doc in docs:
        data = doc.to_dict() or {}
        data["book_title"] = None
        book_doc = db.collection("books").document(data.get("book_id", "")).get()
        if book_doc.exists:
            data["book_title"] = (book_doc.to_dict() or {}).get("title")
        items.append(_doc_to_purchase(data, doc.id).model_dump())

    return {"user_id": user.uid, "items": items}


@router.get("/settings")
def get_settings(user: CurrentUser = Depends(require_role("admin"))):
    if db is None:
        return SystemSettings().model_dump()

    doc = _settings_ref().get()
    if not doc.exists:
        settings = SystemSettings()
        _settings_ref().set(settings.model_dump())
        return settings.model_dump()

    data = doc.to_dict() or {}
    if "updated_at" in data and isinstance(data["updated_at"], datetime):
        data["updated_at"] = data["updated_at"].isoformat()
    return SystemSettings(**data).model_dump()


@router.patch("/settings")
def update_settings(data: dict, user: CurrentUser = Depends(require_role("admin"))):
    if db is None:
        raise HTTPException(status_code=503, detail="Firebase no configurado")

    current_doc = _settings_ref().get()
    current = current_doc.to_dict() if current_doc.exists else SystemSettings().model_dump()
    merged = {**current, **{k: v for k, v in data.items() if v is not None}, "updated_at": datetime.utcnow()}
    settings = SystemSettings(**merged)
    _settings_ref().set(settings.model_dump())
    return settings.model_dump()
