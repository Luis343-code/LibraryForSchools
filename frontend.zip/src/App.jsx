import React, { useEffect, useMemo, useState } from "react";
import "./App.css";
import {
  AlertTriangle,
  BookOpen,
  ChevronRight,
  Heart,
  LoaderCircle,
  LogOut,
  MessageSquare,
  Package,
  Plus,
  Save,
  Search,
  Send,
  Settings,
  Shield,
  ShoppingCart,
  Trash2,
  UserPlus,
  Users,
} from "lucide-react";
import { BarChart, Bar, Cell, Pie, PieChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";

import { api } from "../services/api";
import { auth, loginWithEmail, logout, registerWithEmail, subscribeToAuth } from "../services/firebase";

const ROLE_LABELS = {
  student: "Aprendiz de Letras",
  librarian: "Custodio de Volumenes",
  admin: "Archimago del Sistema",
};

const MENU_BY_ROLE = {
  student: [
    { id: "catalog", label: "Catalogo", icon: <BookOpen size={16} /> },
    { id: "loans", label: "Mis Prestamos", icon: <Package size={16} /> },
    { id: "store", label: "Tienda Digital", icon: <ShoppingCart size={16} /> },
    { id: "community", label: "Comunidad", icon: <MessageSquare size={16} /> },
  ],
  librarian: [
    { id: "books", label: "Gestion de Libros", icon: <BookOpen size={16} /> },
    { id: "loanmgmt", label: "Prestamos", icon: <Package size={16} /> },
    { id: "community", label: "Moderacion", icon: <Shield size={16} /> },
  ],
  admin: [
    { id: "dashboard", label: "Dashboard", icon: <Shield size={16} /> },
    { id: "users", label: "Usuarios", icon: <Users size={16} /> },
    { id: "settings", label: "Configuracion", icon: <Settings size={16} /> },
  ],
};

const DEMO_USERS = [
  { name: "Archimago Zephyr", email: "admin@biblioteca.edu", password: "Admin1234!", role: "admin" },
  { name: "Archivista Aldric", email: "librarian@biblioteca.edu", password: "Custodio1!", role: "librarian" },
  { name: "Elena Beaumont", email: "student@biblioteca.edu", password: "Lector123!", role: "student" },
];

const CHART_COLORS = ["#C8A951", "#2D6A4F", "#1E3A8A", "#8B1A1A", "#7C5C1D"];

const EMPTY_BOOK_FORM = {
  title: "",
  author: "",
  publisher: "",
  year: "",
  category: "",
  synopsis: "",
  cover_color: "#1E3A8A",
  book_type: "both",
  total_copies: "1",
  available_copies: "1",
  digital_price: "0",
  rating: "4.5",
  tags: "",
};

const EMPTY_SETTINGS = {
  library_name: "La Biblioteca de los Ecos",
  loan_days: 21,
  max_loans_per_user: 3,
  late_fee_policy: "1 dia de espera por dia de retraso",
  due_soon_days: 5,
};

function toErrorMessage(error) {
  if (!error) {
    return "Ocurrio un error inesperado.";
  }
  const raw = typeof error === "string" ? error : error.message || "Ocurrio un error inesperado.";
  try {
    const parsed = JSON.parse(raw);
    return parsed.detail || raw;
  } catch {
    return raw;
  }
}

function formatDate(value) {
  if (!value) {
    return "Sin fecha";
  }
  return new Date(value).toLocaleDateString("es-CR", {
    year: "numeric",
    month: "short",
    day: "numeric",
  });
}

function formatDateTime(value) {
  if (!value) {
    return "Ahora";
  }
  return new Date(value).toLocaleString("es-CR", {
    year: "numeric",
    month: "short",
    day: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });
}

function mapBookToForm(book) {
  return {
    title: book.title || "",
    author: book.author || "",
    publisher: book.publisher || "",
    year: String(book.year || ""),
    category: book.category || "",
    synopsis: book.synopsis || "",
    cover_color: book.cover_color || "#1E3A8A",
    book_type: book.book_type || "both",
    total_copies: String(book.total_copies ?? 1),
    available_copies: String(book.available_copies ?? 1),
    digital_price: String(book.digital_price ?? 0),
    rating: String(book.rating ?? 4.5),
    tags: Array.isArray(book.tags) ? book.tags.join(", ") : "",
  };
}

function buildBookPayload(form) {
  return {
    title: form.title.trim(),
    author: form.author.trim(),
    publisher: form.publisher.trim(),
    year: Number(form.year),
    category: form.category.trim(),
    synopsis: form.synopsis.trim(),
    cover_color: form.cover_color.trim() || "#1E3A8A",
    book_type: form.book_type,
    total_copies: Number(form.total_copies),
    available_copies: Number(form.available_copies),
    digital_price: Number(form.digital_price),
    rating: Number(form.rating),
    tags: form.tags
      .split(",")
      .map((item) => item.trim())
      .filter(Boolean),
  };
}

function Notification({ message, onDone }) {
  useEffect(() => {
    const timer = setTimeout(onDone, 3200);
    return () => clearTimeout(timer);
  }, [onDone]);

  return <div className="notif">{message}</div>;
}

function LoadingScreen({ label = "Cargando la biblioteca..." }) {
  return (
    <div className="lbg">
      <div className="lcard loading-card">
        <LoaderCircle className="spin" size={34} />
        <div className="ltitle">La Biblioteca de los Ecos</div>
        <div className="lsub">{label}</div>
      </div>
    </div>
  );
}

function EmptyState({ icon, title, text }) {
  return (
    <div className="empty-state">
      <div className="es-icon">{icon}</div>
      <p>{title}</p>
      <span className="empty-copy">{text}</span>
    </div>
  );
}

function Sidebar({ role, page, setPage, user, onLogout }) {
  return (
    <div className="sidebar">
      <div className="slogo">
        <div className="slogo-t">BIBLIOTECA</div>
        <div className="slogo-s">De los Ecos · Est. MMXXV</div>
      </div>

      <div className="ssec">
        <div className="ssec-l">Navegacion</div>
        {MENU_BY_ROLE[role].map((item) => (
          <button
            type="button"
            key={item.id}
            className={`sitem${page === item.id ? " active" : ""}`}
            onClick={() => setPage(item.id)}
          >
            {item.icon}
            <span>{item.label}</span>
          </button>
        ))}
      </div>

      <div className="suser">
        <div className="profile-mark">{(user.name || "U")[0].toUpperCase()}</div>
        <div className="suser-n">{user.name}</div>
        <div className="suser-r">{ROLE_LABELS[role]}</div>
        <button type="button" className="slogout" onClick={onLogout}>
          <LogOut size={14} />
          Cerrar sesion
        </button>
      </div>
    </div>
  );
}

function BookCard({ book, actionLabel, onAction, secondaryLabel, onSecondaryAction, onSelect }) {
  return (
    <div className="bcard">
      <button type="button" className="cover-button" onClick={() => onSelect(book)}>
        <div className="bcover" style={{ background: book.cover_color || "#1E3A8A" }}>
          <div className="btype btype-b">
            {book.book_type === "physical" ? "Fisico" : book.book_type === "digital" ? "Digital" : "Mixto"}
          </div>
          <div className="bcover-t">{book.title}</div>
          <div className="bcover-a">{book.author}</div>
        </div>
      </button>
      <div className="binfo">
        <div className="bcat">{book.category}</div>
        <div className="book-meta-row">
          <span className={`bavail ${book.available_copies === 0 ? "no" : book.available_copies <= 1 ? "low" : "ok"}`}>
            {book.available_copies}/{book.total_copies} disponibles
          </span>
          <span className="brat">{Number(book.rating || 0).toFixed(1)}</span>
        </div>
        <div className="card-actions">
          {actionLabel ? (
            <button type="button" className="btn btn-g compact-btn" onClick={() => onAction(book)}>
              {actionLabel}
            </button>
          ) : null}
          {secondaryLabel ? (
            <button type="button" className="btn btn-o compact-btn" onClick={() => onSecondaryAction(book)}>
              {secondaryLabel}
            </button>
          ) : null}
        </div>
      </div>
    </div>
  );
}

function BookModal({ book, onClose, primaryAction, secondaryAction }) {
  if (!book) {
    return null;
  }

  return (
    <div className="movl" onClick={onClose}>
      <div className="modal" onClick={(event) => event.stopPropagation()}>
        <button type="button" className="mclose" onClick={onClose}>
          <Trash2 size={18} />
        </button>
        <div className="mhdr">
          <div className="mcover" style={{ background: book.cover_color || "#1E3A8A" }}>
            <div className="mcover-t">{book.title}</div>
          </div>
          <div className="minfo">
            <div className="mtitle">{book.title}</div>
            <div className="mauthor">{book.author}</div>
            <div className="mmeta">
              <span className="mtag">{book.category}</span>
              <span className="mtag">{book.publisher}</span>
              <span className="mtag">{book.year}</span>
              <span className="mtag">${Number(book.digital_price || 0).toFixed(2)}</span>
            </div>
          </div>
        </div>
        <div className="mbody">
          <div className="mstitle">Sinopsis</div>
          <div className="msynopsis">{book.synopsis || "Sin sinopsis disponible."}</div>
          <div className="macts">
            {primaryAction}
            {secondaryAction}
          </div>
        </div>
      </div>
    </div>
  );
}

function AuthScreen({ onNotify }) {
  const [mode, setMode] = useState("login");
  const [form, setForm] = useState({ name: "", email: "", password: "" });
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState("");

  async function handleSubmit(event) {
    event.preventDefault();
    setSubmitting(true);
    setError("");

    try {
      if (mode === "login") {
        await loginWithEmail(form.email.trim(), form.password);
      } else {
        const result = await registerWithEmail({
          name: form.name.trim(),
          email: form.email.trim(),
          password: form.password,
        });
        const token = await result.user.getIdToken();
        await api.register({
          uid: result.user.uid,
          name: form.name.trim() || result.user.displayName || "Nuevo lector",
          email: form.email.trim(),
          role: "student",
          avatar_url: null,
        });
        await api.me(token);
        onNotify("Cuenta creada y vinculada con la biblioteca.");
      }
    } catch (err) {
      setError(toErrorMessage(err));
    } finally {
      setSubmitting(false);
    }
  }

  function fillDemo(user) {
    setForm({ name: user.name, email: user.email, password: user.password });
    setMode("login");
  }

  return (
    <div className="lbg">
      <div className="lcard">
        <div className="llogo">
          <div className="ltitle">La Biblioteca de los Ecos</div>
          <div className="lsub">Acceso real con Firebase Auth y datos persistentes</div>
        </div>

        <div className="tab-bar auth-tabs">
          <button type="button" className={`tab-item${mode === "login" ? " active" : ""}`} onClick={() => setMode("login")}>
            Entrar
          </button>
          <button type="button" className={`tab-item${mode === "register" ? " active" : ""}`} onClick={() => setMode("register")}>
            Crear cuenta
          </button>
        </div>

        <form onSubmit={handleSubmit}>
          {mode === "register" ? (
            <div className="lfield">
              <label>Nombre</label>
              <input
                value={form.name}
                onChange={(event) => setForm((current) => ({ ...current, name: event.target.value }))}
                placeholder="Tu nombre"
              />
            </div>
          ) : null}

          <div className="lfield">
            <label>Correo</label>
            <input
              value={form.email}
              onChange={(event) => setForm((current) => ({ ...current, email: event.target.value }))}
              placeholder="tu.nombre@biblioteca.edu"
            />
          </div>

          <div className="lfield">
            <label>Contrasena</label>
            <input
              type="password"
              value={form.password}
              onChange={(event) => setForm((current) => ({ ...current, password: event.target.value }))}
              placeholder="••••••••"
            />
          </div>

          {error ? <div className="error-banner">{error}</div> : null}

          <button type="submit" className="lbtn" disabled={submitting}>
            {submitting ? "Procesando..." : mode === "login" ? "Entrar" : "Crear cuenta"}
          </button>
        </form>

        <div className="ldemo">
          <div className="ldemo-t">Credenciales sembradas</div>
          {DEMO_USERS.map((user) => (
            <button type="button" key={user.email} className="ldemo-row demo-button" onClick={() => fillDemo(user)}>
              <span className="ldemo-role">{ROLE_LABELS[user.role]}</span>
              <span className="ldemo-creds">
                {user.email} / {user.password}
              </span>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}

function StudentPortal({ session, onNotify, onLogout }) {
  const [page, setPage] = useState("catalog");
  const [books, setBooks] = useState([]);
  const [categories, setCategories] = useState([]);
  const [loans, setLoans] = useState([]);
  const [purchases, setPurchases] = useState([]);
  const [posts, setPosts] = useState([]);
  const [commentsByPost, setCommentsByPost] = useState({});
  const [loading, setLoading] = useState(true);
  const [selectedBook, setSelectedBook] = useState(null);
  const [search, setSearch] = useState("");
  const [category, setCategory] = useState("");
  const [draftPost, setDraftPost] = useState("");
  const [draftBookId, setDraftBookId] = useState("");
  const [commentDrafts, setCommentDrafts] = useState({});
  const [expandedPostId, setExpandedPostId] = useState(null);

  async function loadBooks() {
    const [booksResponse, categoriesResponse] = await Promise.all([api.getBooks(), api.getCategories()]);
    setBooks(booksResponse.items || []);
    setCategories(categoriesResponse.items || []);
  }

  async function loadLoans() {
    const response = await api.getLoans(session.token);
    setLoans(response.items || []);
  }

  async function loadPurchases() {
    const response = await api.getPurchases(session.token);
    setPurchases(response.items || []);
  }

  async function loadPosts() {
    const response = await api.getPosts();
    setPosts(response.items || []);
  }

  useEffect(() => {
    let active = true;

    (async () => {
      try {
        await Promise.all([loadBooks(), loadLoans(), loadPurchases(), loadPosts()]);
      } catch (error) {
        onNotify(toErrorMessage(error));
      } finally {
        if (active) {
          setLoading(false);
        }
      }
    })();

    return () => {
      active = false;
    };
  }, [session.token]);

  const purchasedIds = useMemo(() => new Set(purchases.map((purchase) => purchase.book_id)), [purchases]);
  const filteredBooks = useMemo(
    () =>
      books.filter((book) => {
        const matchesCategory = !category || book.category === category;
        const haystack = `${book.title} ${book.author} ${book.category}`.toLowerCase();
        return matchesCategory && haystack.includes(search.toLowerCase());
      }),
    [books, category, search]
  );

  async function handleLoanRequest(book) {
    try {
      await api.createLoan(session.token, { book_id: book.id, user_id: session.profile.uid, days: 21 });
      await loadLoans();
      await loadBooks();
      onNotify("Solicitud de prestamo enviada.");
    } catch (error) {
      onNotify(toErrorMessage(error));
    }
  }

  async function handlePurchase(book) {
    try {
      await api.createPurchase(session.token, {
        book_id: book.id,
        user_id: session.profile.uid,
        payment_ref: `web-${Date.now()}`,
      });
      await loadPurchases();
      onNotify("Compra digital registrada.");
    } catch (error) {
      onNotify(toErrorMessage(error));
    }
  }

  async function handleCreatePost() {
    if (!draftPost.trim()) {
      return;
    }

    try {
      await api.createPost(session.token, {
        content: draftPost.trim(),
        book_id: draftBookId || null,
      });
      setDraftPost("");
      setDraftBookId("");
      await loadPosts();
      onNotify("Publicacion guardada.");
    } catch (error) {
      onNotify(toErrorMessage(error));
    }
  }

  async function handleToggleLike(postId) {
    try {
      const response = await api.likePost(session.token, postId);
      setPosts((current) =>
        current.map((post) =>
          post.id === postId ? { ...post, likes: response.likes, liked: response.liked } : post
        )
      );
    } catch (error) {
      onNotify(toErrorMessage(error));
    }
  }

  async function toggleComments(postId) {
    if (expandedPostId === postId) {
      setExpandedPostId(null);
      return;
    }

    setExpandedPostId(postId);
    if (!commentsByPost[postId]) {
      try {
        const response = await api.getComments(postId);
        setCommentsByPost((current) => ({ ...current, [postId]: response.items || [] }));
      } catch (error) {
        onNotify(toErrorMessage(error));
      }
    }
  }

  async function handleCreateComment(postId) {
    const value = (commentDrafts[postId] || "").trim();
    if (!value) {
      return;
    }

    try {
      const response = await api.createComment(session.token, postId, { content: value });
      setCommentDrafts((current) => ({ ...current, [postId]: "" }));
      setCommentsByPost((current) => ({
        ...current,
        [postId]: [...(current[postId] || []), response.item],
      }));
      setPosts((current) =>
        current.map((post) =>
          post.id === postId ? { ...post, comments_count: (post.comments_count || 0) + 1 } : post
        )
      );
    } catch (error) {
      onNotify(toErrorMessage(error));
    }
  }

  async function handleDeletePost(postId) {
    try {
      await api.deletePost(session.token, postId);
      setPosts((current) => current.filter((post) => post.id !== postId));
      onNotify("Publicacion eliminada.");
    } catch (error) {
      onNotify(toErrorMessage(error));
    }
  }

  if (loading) {
    return <LoadingScreen label="Consultando catalogo, prestamos y comunidad..." />;
  }

  return (
    <div className="app">
      <Sidebar role="student" page={page} setPage={setPage} user={session.profile} onLogout={onLogout} />
      <div className="main">
        {page === "catalog" ? (
          <div className="page">
            <div className="ph">
              <div className="ptitle">Catalogo vivo</div>
              <div className="psub">Los libros ya salen de Firestore y las solicitudes de prestamo se guardan de verdad.</div>
            </div>

            <div className="sbar">
              <div className="sinp-w">
                <Search size={14} />
                <input className="sinp" value={search} onChange={(event) => setSearch(event.target.value)} placeholder="Buscar titulo o autor" />
              </div>
              <select className="fsel" value={category} onChange={(event) => setCategory(event.target.value)}>
                <option value="">Todas las categorias</option>
                {categories.map((item) => (
                  <option key={item} value={item}>
                    {item}
                  </option>
                ))}
              </select>
            </div>

            {!filteredBooks.length ? (
              <EmptyState icon="📚" title="No hay libros para ese filtro." text="Prueba otra categoria o una busqueda mas amplia." />
            ) : (
              <div className="bgrid">
                {filteredBooks.map((book) => (
                  <BookCard
                    key={book.id}
                    book={book}
                    onSelect={setSelectedBook}
                    actionLabel={book.available_copies > 0 ? "Pedir prestamo" : "Sin copias"}
                    onAction={handleLoanRequest}
                    secondaryLabel={book.book_type !== "physical" ? "Comprar digital" : null}
                    onSecondaryAction={handlePurchase}
                  />
                ))}
              </div>
            )}
          </div>
        ) : null}

        {page === "loans" ? (
          <div className="page">
            <div className="ph">
              <div className="ptitle">Mis prestamos</div>
              <div className="psub">Aqui ves el estado real de tus solicitudes y ejemplares activos.</div>
            </div>

            {!loans.length ? (
              <EmptyState icon="📦" title="Todavia no tienes prestamos." text="Pide uno desde el catalogo y aparecera aqui." />
            ) : (
              loans.map((loan) => (
                <div className="lcard2" key={loan.id}>
                  <div className="li">
                    <div className="li-t">{loan.book_title || "Libro"}</div>
                    <div className="li-a">{loan.book_author || "Autor desconocido"}</div>
                    <div className="li-s">
                      <span className="chip chip-p">{loan.status}</span>
                      <span>Solicitado: {formatDate(loan.requested_at)}</span>
                      <span>Entrega: {formatDate(loan.due_date)}</span>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        ) : null}

        {page === "store" ? (
          <div className="page">
            <div className="ph">
              <div className="ptitle">Tienda digital</div>
              <div className="psub">Las compras quedan registradas y reaparecen cuando vuelves a entrar.</div>
            </div>

            <div className="sgrid">
              {books
                .filter((book) => book.book_type !== "physical")
                .map((book) => (
                  <div className="scard" key={book.id}>
                    <div className="scover" style={{ background: book.cover_color || "#1E3A8A" }}>
                      <div className="stitle">{book.title}</div>
                    </div>
                    <div className="sinfo">
                      <div>{book.author}</div>
                      <div className="sprice">${Number(book.digital_price || 0).toFixed(2)}</div>
                      <button
                        type="button"
                        className="btn btn-g compact-btn full-width"
                        disabled={purchasedIds.has(book.id)}
                        onClick={() => handlePurchase(book)}
                      >
                        {purchasedIds.has(book.id) ? "Comprado" : "Comprar"}
                      </button>
                    </div>
                  </div>
                ))}
            </div>

            <div className="cbox">
              <div className="cbox-t">Mis compras</div>
              {!purchases.length ? (
                <EmptyState icon="🛒" title="Aun no has comprado ebooks." text="Los libros digitales que compres apareceran aqui." />
              ) : (
                purchases.map((purchase) => (
                  <div className="list-row" key={purchase.id}>
                    <div>
                      <strong>{purchase.book_title || purchase.book_id}</strong>
                      <div className="muted-row">{formatDateTime(purchase.created_at)}</div>
                    </div>
                    <span className="chip chip-a">Disponible</span>
                  </div>
                ))
              )}
            </div>
          </div>
        ) : null}

        {page === "community" ? (
          <div className="page">
            <div className="ph">
              <div className="ptitle">Comunidad</div>
              <div className="psub">Publicaciones, likes y comentarios conectados a Firestore.</div>
            </div>

            <div className="cbox">
              <div className="cbox-t">Nueva publicacion</div>
              <div className="ff">
                <label>Libro relacionado</label>
                <select className="fsel" value={draftBookId} onChange={(event) => setDraftBookId(event.target.value)}>
                  <option value="">Sin libro asociado</option>
                  {books.map((book) => (
                    <option key={book.id} value={book.id}>
                      {book.title}
                    </option>
                  ))}
                </select>
              </div>
              <div className="pinp-w" style={{ marginTop: 14 }}>
                <textarea className="pinp" rows={4} value={draftPost} onChange={(event) => setDraftPost(event.target.value)} placeholder="Comparte una idea, una recomendacion o una cita." />
                <button type="button" className="btn btn-g compact-btn" onClick={handleCreatePost}>
                  <Send size={14} />
                </button>
              </div>
            </div>

            {!posts.length ? (
              <EmptyState icon="🌐" title="No hay publicaciones todavia." text="La primera puede salir de aqui mismo." />
            ) : (
              posts.map((post) => (
                <div className="post" key={post.id}>
                  <div className="phdr2">
                    <div className="pavt">{post.user_avatar_initial || (post.user_name || "A")[0]}</div>
                    <div>
                      <div className="pun">{post.user_name || "Anonimo"}</div>
                      <div className="ptm">{formatDateTime(post.created_at)}</div>
                    </div>
                    {post.book_title ? <div className="pbtag">{post.book_title}</div> : null}
                    {post.user_id === session.profile.uid ? (
                      <button type="button" className="abtn abtn-d" onClick={() => handleDeletePost(post.id)}>
                        <Trash2 size={10} />
                      </button>
                    ) : null}
                  </div>
                  <div className="pcont">{post.content}</div>
                  <div className="pacts">
                    <button type="button" className={`pact${post.liked ? " liked" : ""}`} onClick={() => handleToggleLike(post.id)}>
                      <Heart size={13} /> {post.likes || 0}
                    </button>
                    <button type="button" className="pact" onClick={() => toggleComments(post.id)}>
                      <MessageSquare size={13} /> {post.comments_count || 0}
                    </button>
                  </div>

                  {expandedPostId === post.id ? (
                    <div className="comments-box">
                      {(commentsByPost[post.id] || []).map((comment) => (
                        <div key={comment.id} className="comment-row">
                          <div className="comment-avatar">{comment.user_avatar_initial || "A"}</div>
                          <div>
                            <strong>{comment.user_name || "Anonimo"}</strong>
                            <div className="muted-row">{comment.content}</div>
                          </div>
                        </div>
                      ))}
                      <div className="pinp-w" style={{ marginBottom: 0 }}>
                        <input
                          className="pinp"
                          value={commentDrafts[post.id] || ""}
                          onChange={(event) =>
                            setCommentDrafts((current) => ({ ...current, [post.id]: event.target.value }))
                          }
                          placeholder="Escribe un comentario"
                        />
                        <button type="button" className="btn btn-g compact-btn" onClick={() => handleCreateComment(post.id)}>
                          <Send size={14} />
                        </button>
                      </div>
                    </div>
                  ) : null}
                </div>
              ))
            )}
          </div>
        ) : null}
      </div>

      <BookModal
        book={selectedBook}
        onClose={() => setSelectedBook(null)}
        primaryAction={
          <button type="button" className="btn btn-g" onClick={() => handleLoanRequest(selectedBook)}>
            Pedir prestamo
          </button>
        }
        secondaryAction={
          selectedBook?.book_type !== "physical" ? (
            <button type="button" className="btn btn-o" onClick={() => handlePurchase(selectedBook)}>
              Comprar digital
            </button>
          ) : null
        }
      />
    </div>
  );
}

function LibrarianPortal({ session, onNotify, onLogout }) {
  const [page, setPage] = useState("books");
  const [books, setBooks] = useState([]);
  const [loans, setLoans] = useState([]);
  const [posts, setPosts] = useState([]);
  const [categories, setCategories] = useState([]);
  const [bookForm, setBookForm] = useState(EMPTY_BOOK_FORM);
  const [editingBookId, setEditingBookId] = useState(null);
  const [loading, setLoading] = useState(true);

  async function loadBooks() {
    const [booksResponse, categoriesResponse] = await Promise.all([api.getBooks(), api.getCategories()]);
    setBooks(booksResponse.items || []);
    setCategories(categoriesResponse.items || []);
  }

  async function loadLoans() {
    const response = await api.getLoans(session.token);
    setLoans(response.items || []);
  }

  async function loadPosts() {
    const response = await api.getPosts();
    setPosts(response.items || []);
  }

  useEffect(() => {
    let active = true;

    (async () => {
      try {
        await Promise.all([loadBooks(), loadLoans(), loadPosts()]);
      } catch (error) {
        onNotify(toErrorMessage(error));
      } finally {
        if (active) {
          setLoading(false);
        }
      }
    })();

    return () => {
      active = false;
    };
  }, [session.token]);

  async function submitBook(event) {
    event.preventDefault();

    try {
      const payload = buildBookPayload(bookForm);
      if (editingBookId) {
        await api.updateBook(session.token, editingBookId, payload);
        onNotify("Libro actualizado.");
      } else {
        await api.createBook(session.token, payload);
        onNotify("Libro creado.");
      }
      setBookForm(EMPTY_BOOK_FORM);
      setEditingBookId(null);
      await loadBooks();
    } catch (error) {
      onNotify(toErrorMessage(error));
    }
  }

  async function handleDeleteBook(bookId) {
    try {
      await api.deleteBook(session.token, bookId);
      await loadBooks();
      onNotify("Libro eliminado.");
    } catch (error) {
      onNotify(toErrorMessage(error));
    }
  }

  async function handleLoanReview(loanId, status) {
    try {
      await api.reviewLoan(session.token, loanId, { status });
      await Promise.all([loadLoans(), loadBooks()]);
      onNotify(`Prestamo ${status === "active" ? "aprobado" : "denegado"}.`);
    } catch (error) {
      onNotify(toErrorMessage(error));
    }
  }

  async function handleReturn(loanId) {
    try {
      await api.returnLoan(session.token, loanId);
      await Promise.all([loadLoans(), loadBooks()]);
      onNotify("Prestamo marcado como devuelto.");
    } catch (error) {
      onNotify(toErrorMessage(error));
    }
  }

  async function handleDeletePost(postId) {
    try {
      await api.deletePost(session.token, postId);
      await loadPosts();
      onNotify("Publicacion retirada.");
    } catch (error) {
      onNotify(toErrorMessage(error));
    }
  }

  if (loading) {
    return <LoadingScreen label="Preparando gestion de libros, prestamos y comunidad..." />;
  }

  return (
    <div className="app">
      <Sidebar role="librarian" page={page} setPage={setPage} user={session.profile} onLogout={onLogout} />
      <div className="main">
        {page === "books" ? (
          <div className="page">
            <div className="ph">
              <div className="ptitle">Gestion de libros</div>
              <div className="psub">Crear, editar y eliminar libros ya impacta el catalogo real.</div>
            </div>

            <form className="addbk-form" onSubmit={submitBook}>
              <div className="cbox-t">{editingBookId ? "Editar volumen" : "Registrar nuevo volumen"}</div>
              <div className="addbk-grid">
                {[
                  ["title", "Titulo"],
                  ["author", "Autor"],
                  ["publisher", "Editorial"],
                  ["year", "Ano"],
                  ["category", "Categoria"],
                  ["cover_color", "Color"],
                  ["total_copies", "Total"],
                  ["available_copies", "Disponibles"],
                  ["digital_price", "Precio digital"],
                  ["rating", "Rating"],
                ].map(([field, label]) => (
                  <div className="ff" key={field}>
                    <label>{label}</label>
                    <input value={bookForm[field]} onChange={(event) => setBookForm((current) => ({ ...current, [field]: event.target.value }))} />
                  </div>
                ))}
                <div className="ff">
                  <label>Tipo</label>
                  <select value={bookForm.book_type} onChange={(event) => setBookForm((current) => ({ ...current, book_type: event.target.value }))}>
                    <option value="both">Fisico y digital</option>
                    <option value="physical">Solo fisico</option>
                    <option value="digital">Solo digital</option>
                  </select>
                </div>
                <div className="ff">
                  <label>Etiquetas</label>
                  <input value={bookForm.tags} onChange={(event) => setBookForm((current) => ({ ...current, tags: event.target.value }))} placeholder="fantasia, epico" />
                </div>
                <div className="ff" style={{ gridColumn: "1 / -1" }}>
                  <label>Sinopsis</label>
                  <textarea value={bookForm.synopsis} onChange={(event) => setBookForm((current) => ({ ...current, synopsis: event.target.value }))} />
                </div>
              </div>
              <div className="form-actions">
                <button type="submit" className="btn btn-g">
                  <Save size={14} /> {editingBookId ? "Guardar cambios" : "Crear libro"}
                </button>
                {editingBookId ? (
                  <button type="button" className="btn btn-o" onClick={() => { setEditingBookId(null); setBookForm(EMPTY_BOOK_FORM); }}>
                    Cancelar edicion
                  </button>
                ) : null}
              </div>
            </form>

            <div className="cbox">
              <div className="cbox-t">Catalogo actual</div>
              <div style={{ overflowX: "auto" }}>
                <table className="dtable">
                  <thead>
                    <tr>
                      <th>Titulo</th>
                      <th>Autor</th>
                      <th>Categoria</th>
                      <th>Disponibles</th>
                      <th>Tipo</th>
                      <th>Acciones</th>
                    </tr>
                  </thead>
                  <tbody>
                    {books.map((book) => (
                      <tr key={book.id}>
                        <td>{book.title}</td>
                        <td>{book.author}</td>
                        <td>{book.category}</td>
                        <td>{book.available_copies}/{book.total_copies}</td>
                        <td>{book.book_type}</td>
                        <td>
                          <button type="button" className="abtn abtn-e" onClick={() => { setEditingBookId(book.id); setBookForm(mapBookToForm(book)); }}>
                            Editar
                          </button>
                          <button type="button" className="abtn abtn-d" onClick={() => handleDeleteBook(book.id)}>
                            Eliminar
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        ) : null}

        {page === "loanmgmt" ? (
          <div className="page">
            <div className="ph">
              <div className="ptitle">Prestamos</div>
              <div className="psub">Aprobacion, rechazo y devolucion ya actualizan libros y prestamos.</div>
            </div>
            <div className="cbox">
              <div className="cbox-t">Solicitudes y prestamos</div>
              <div style={{ overflowX: "auto" }}>
                <table className="dtable">
                  <thead>
                    <tr>
                      <th>Libro</th>
                      <th>Lector</th>
                      <th>Solicitud</th>
                      <th>Entrega</th>
                      <th>Estado</th>
                      <th>Acciones</th>
                    </tr>
                  </thead>
                  <tbody>
                    {loans.map((loan) => (
                      <tr key={loan.id}>
                        <td>{loan.book_title || loan.book_id}</td>
                        <td>{loan.user_name || loan.user_id}</td>
                        <td>{formatDate(loan.requested_at)}</td>
                        <td>{formatDate(loan.due_date)}</td>
                        <td>{loan.status}</td>
                        <td>
                          {loan.status === "pending" ? (
                            <>
                              <button type="button" className="abtn abtn-a" onClick={() => handleLoanReview(loan.id, "active")}>
                                Aprobar
                              </button>
                              <button type="button" className="abtn abtn-d" onClick={() => handleLoanReview(loan.id, "denied")}>
                                Denegar
                              </button>
                            </>
                          ) : null}
                          {loan.status === "active" || loan.status === "overdue" ? (
                            <button type="button" className="abtn abtn-e" onClick={() => handleReturn(loan.id)}>
                              Marcar devuelto
                            </button>
                          ) : null}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        ) : null}

        {page === "community" ? (
          <div className="page">
            <div className="ph">
              <div className="ptitle">Moderacion</div>
              <div className="psub">Eliminas publicaciones reales, no tarjetas decorativas.</div>
            </div>
            {!posts.length ? (
              <EmptyState icon="🛡️" title="No hay publicaciones." text="Cuando la comunidad escriba, aparecera aqui." />
            ) : (
              posts.map((post) => (
                <div className="post" key={post.id}>
                  <div className="phdr2">
                    <div className="pavt">{post.user_avatar_initial || "A"}</div>
                    <div>
                      <div className="pun">{post.user_name || "Anonimo"}</div>
                      <div className="ptm">{formatDateTime(post.created_at)}</div>
                    </div>
                    {post.book_title ? <div className="pbtag">{post.book_title}</div> : null}
                    <button type="button" className="abtn abtn-d" style={{ marginLeft: "auto" }} onClick={() => handleDeletePost(post.id)}>
                      Eliminar
                    </button>
                  </div>
                  <div className="pcont">{post.content}</div>
                </div>
              ))
            )}
          </div>
        ) : null}
      </div>
    </div>
  );
}

function AdminPortal({ session, onNotify, onLogout }) {
  const [page, setPage] = useState("dashboard");
  const [stats, setStats] = useState(null);
  const [users, setUsers] = useState([]);
  const [books, setBooks] = useState([]);
  const [settingsForm, setSettingsForm] = useState(EMPTY_SETTINGS);
  const [loading, setLoading] = useState(true);

  async function loadDashboard() {
    const [statsResponse, usersResponse, booksResponse, settingsResponse] = await Promise.all([
      api.getStats(session.token),
      api.getUsers(session.token),
      api.getBooks(),
      api.getSettings(session.token),
    ]);
    setStats(statsResponse);
    setUsers(usersResponse.items || []);
    setBooks(booksResponse.items || []);
    setSettingsForm({
      library_name: settingsResponse.library_name,
      loan_days: settingsResponse.loan_days,
      max_loans_per_user: settingsResponse.max_loans_per_user,
      late_fee_policy: settingsResponse.late_fee_policy,
      due_soon_days: settingsResponse.due_soon_days,
    });
  }

  useEffect(() => {
    let active = true;

    (async () => {
      try {
        await loadDashboard();
      } catch (error) {
        onNotify(toErrorMessage(error));
      } finally {
        if (active) {
          setLoading(false);
        }
      }
    })();

    return () => {
      active = false;
    };
  }, [session.token]);

  const categoryData = useMemo(() => {
    const counts = books.reduce((accumulator, book) => {
      accumulator[book.category] = (accumulator[book.category] || 0) + 1;
      return accumulator;
    }, {});
    return Object.entries(counts).map(([name, value]) => ({ name, value }));
  }, [books]);

  const topBooks = useMemo(
    () =>
      [...books]
        .sort((a, b) => Number(b.rating || 0) - Number(a.rating || 0))
        .slice(0, 6)
        .map((book) => ({ name: book.title.slice(0, 18), rating: Number(book.rating || 0) })),
    [books]
  );

  async function handleRoleChange(uid, role) {
    try {
      const updated = await api.updateUser(session.token, uid, { role });
      setUsers((current) => current.map((user) => (user.uid === uid ? { ...user, ...updated } : user)));
      onNotify("Rol actualizado.");
    } catch (error) {
      onNotify(toErrorMessage(error));
    }
  }

  async function handleDeleteUser(uid) {
    try {
      await api.deleteUser(session.token, uid);
      setUsers((current) => current.filter((user) => user.uid !== uid));
      onNotify("Usuario eliminado del registro.");
    } catch (error) {
      onNotify(toErrorMessage(error));
    }
  }

  async function handleSaveSettings(event) {
    event.preventDefault();
    try {
      const updated = await api.updateSettings(session.token, {
        ...settingsForm,
        loan_days: Number(settingsForm.loan_days),
        max_loans_per_user: Number(settingsForm.max_loans_per_user),
        due_soon_days: Number(settingsForm.due_soon_days),
      });
      setSettingsForm({
        library_name: updated.library_name,
        loan_days: updated.loan_days,
        max_loans_per_user: updated.max_loans_per_user,
        late_fee_policy: updated.late_fee_policy,
        due_soon_days: updated.due_soon_days,
      });
      onNotify("Configuracion guardada.");
    } catch (error) {
      onNotify(toErrorMessage(error));
    }
  }

  if (loading || !stats) {
    return <LoadingScreen label="Cargando tablero de control del sistema..." />;
  }

  return (
    <div className="app">
      <Sidebar role="admin" page={page} setPage={setPage} user={session.profile} onLogout={onLogout} />
      <div className="main">
        {page === "dashboard" ? (
          <div className="page">
            <div className="ph">
              <div className="ptitle">Dashboard del Archimago</div>
              <div className="psub">Lectores, libros, prestamos y comunidad salen del estado real del sistema.</div>
            </div>

            <div className="statg">
              <div className="stcard">
                <div className="stnum">{stats.books}</div>
                <div className="stlbl">Libros</div>
              </div>
              <div className="stcard">
                <div className="stnum">{stats.users}</div>
                <div className="stlbl">Usuarios</div>
              </div>
              <div className="stcard">
                <div className="stnum">{stats.active_loans}</div>
                <div className="stlbl">Prestamos activos</div>
              </div>
              <div className="stcard">
                <div className="stnum" style={{ color: "#E05252" }}>{stats.overdue_loans || 0}</div>
                <div className="stlbl">Prestamos vencidos</div>
              </div>
            </div>

            <div className="chart-grid">
              <div className="cbox">
                <div className="cbox-t">Categorias</div>
                <ResponsiveContainer width="100%" height={220}>
                  <PieChart>
                    <Pie data={categoryData} dataKey="value" nameKey="name" innerRadius={50} outerRadius={80}>
                      {categoryData.map((entry, index) => (
                        <Cell key={entry.name} fill={CHART_COLORS[index % CHART_COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip />
                  </PieChart>
                </ResponsiveContainer>
              </div>

              <div className="cbox">
                <div className="cbox-t">Mejor valorados</div>
                <ResponsiveContainer width="100%" height={220}>
                  <BarChart data={topBooks} layout="vertical" margin={{ left: 12, right: 12 }}>
                    <XAxis type="number" domain={[0, 5]} />
                    <YAxis dataKey="name" type="category" width={110} />
                    <Tooltip />
                    <Bar dataKey="rating" fill="#C8A951" radius={[0, 6, 6, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>
          </div>
        ) : null}

        {page === "users" ? (
          <div className="page">
            <div className="ph">
              <div className="ptitle">Usuarios</div>
              <div className="psub">Cambio de roles persistente y eliminacion del registro del sistema.</div>
            </div>
            <div className="cbox">
              <div style={{ overflowX: "auto" }}>
                <table className="dtable">
                  <thead>
                    <tr>
                      <th>Nombre</th>
                      <th>Correo</th>
                      <th>Rol</th>
                      <th>Prestamos</th>
                      <th>Acciones</th>
                    </tr>
                  </thead>
                  <tbody>
                    {users.map((user) => (
                      <tr key={user.uid}>
                        <td>{user.name}</td>
                        <td>{user.email}</td>
                        <td>
                          <select className="role-select" value={user.role} onChange={(event) => handleRoleChange(user.uid, event.target.value)}>
                            <option value="student">student</option>
                            <option value="librarian">librarian</option>
                            <option value="admin">admin</option>
                          </select>
                        </td>
                        <td>{user.loans_count || 0}</td>
                        <td>
                          {user.uid !== session.profile.uid ? (
                            <button type="button" className="abtn abtn-d" onClick={() => handleDeleteUser(user.uid)}>
                              Eliminar
                            </button>
                          ) : (
                            <span className="muted-row">Tu cuenta</span>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        ) : null}

        {page === "settings" ? (
          <div className="page">
            <div className="ph">
              <div className="ptitle">Configuracion</div>
              <div className="psub">Estos valores ahora se guardan en Firestore.</div>
            </div>
            <form className="addbk-form" onSubmit={handleSaveSettings}>
              <div className="addbk-grid">
                <div className="ff">
                  <label>Nombre de la biblioteca</label>
                  <input value={settingsForm.library_name} onChange={(event) => setSettingsForm((current) => ({ ...current, library_name: event.target.value }))} />
                </div>
                <div className="ff">
                  <label>Dias de prestamo</label>
                  <input value={settingsForm.loan_days} onChange={(event) => setSettingsForm((current) => ({ ...current, loan_days: event.target.value }))} />
                </div>
                <div className="ff">
                  <label>Limite por lector</label>
                  <input value={settingsForm.max_loans_per_user} onChange={(event) => setSettingsForm((current) => ({ ...current, max_loans_per_user: event.target.value }))} />
                </div>
                <div className="ff">
                  <label>Recordatorio previo</label>
                  <input value={settingsForm.due_soon_days} onChange={(event) => setSettingsForm((current) => ({ ...current, due_soon_days: event.target.value }))} />
                </div>
                <div className="ff" style={{ gridColumn: "1 / -1" }}>
                  <label>Politica de retraso</label>
                  <textarea value={settingsForm.late_fee_policy} onChange={(event) => setSettingsForm((current) => ({ ...current, late_fee_policy: event.target.value }))} />
                </div>
              </div>
              <div className="form-actions">
                <button type="submit" className="btn btn-g">
                  <Save size={14} /> Guardar configuracion
                </button>
              </div>
            </form>
          </div>
        ) : null}
      </div>
    </div>
  );
}

export default function App() {
  const [session, setSession] = useState(null);
  const [booting, setBooting] = useState(true);
  const [notification, setNotification] = useState("");

  useEffect(() => {
    return subscribeToAuth(async (firebaseUser) => {
      if (!firebaseUser) {
        setSession(null);
        setBooting(false);
        return;
      }

      try {
        const token = await firebaseUser.getIdToken();
        const profile = await api.me(token);
        setSession({ firebaseUser, token, profile });
      } catch (error) {
        setNotification(toErrorMessage(error));
        await logout();
      } finally {
        setBooting(false);
      }
    });
  }, []);

  async function handleLogout() {
    await logout();
    setSession(null);
  }

  if (booting) {
    return <LoadingScreen />;
  }

  return (
    <>
      {notification ? <Notification message={notification} onDone={() => setNotification("")} /> : null}
      {!session ? <AuthScreen onNotify={setNotification} /> : null}
      {session?.profile.role === "student" ? (
        <StudentPortal session={session} onNotify={setNotification} onLogout={handleLogout} />
      ) : null}
      {session?.profile.role === "librarian" ? (
        <LibrarianPortal session={session} onNotify={setNotification} onLogout={handleLogout} />
      ) : null}
      {session?.profile.role === "admin" ? (
        <AdminPortal session={session} onNotify={setNotification} onLogout={handleLogout} />
      ) : null}
    </>
  );
}
