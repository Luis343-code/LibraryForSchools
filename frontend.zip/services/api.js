const configuredUrl = import.meta.env.VITE_API_URL || "http://localhost:8000/api/v1";
const API_ROOT = configuredUrl.replace(/\/+$/, "");
const API_BASE = API_ROOT.replace(/\/api\/v1$/, "");

async function request(path, { method = "GET", token, body, headers = {} } = {}) {
  const response = await fetch(`${API_ROOT}${path}`, {
    method,
    headers: {
      ...(body instanceof FormData ? {} : { "Content-Type": "application/json" }),
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
      ...headers,
    },
    body: body instanceof FormData ? body : body ? JSON.stringify(body) : undefined,
  });

  if (!response.ok) {
    const errorText = await response.text();
    throw new Error(errorText || `HTTP ${response.status}`);
  }

  if (response.status === 204) {
    return null;
  }

  const contentType = response.headers.get("content-type") || "";
  return contentType.includes("application/json") ? response.json() : response.text();
}

export const api = {
  health: async () => {
    const response = await fetch(`${API_BASE}/health`);
    if (!response.ok) {
      throw new Error(`HTTP ${response.status}`);
    }
    return response.json();
  },

  me: (token) => request("/auth/me", { token }),
  register: (userData) => request("/auth/register", { method: "POST", body: userData }),
  updateMe: (token, userData) => request("/auth/me", { method: "PATCH", token, body: userData }),

  getBooks: (params = {}) => {
    const qs = new URLSearchParams(
      Object.entries(params).filter(([, value]) => value !== undefined && value !== null && value !== "")
    ).toString();
    return request(`/books/${qs ? `?${qs}` : ""}`);
  },
  getBook: (id) => request(`/books/${id}`),
  createBook: (token, book) => request("/books/", { method: "POST", token, body: book }),
  updateBook: (token, id, book) => request(`/books/${id}`, { method: "PATCH", token, body: book }),
  deleteBook: (token, id) => request(`/books/${id}`, { method: "DELETE", token }),
  getCategories: () => request("/books/meta/categories"),

  getLoans: (token, status) => {
    const qs = status ? `?status=${encodeURIComponent(status)}` : "";
    return request(`/loans/${qs}`, { token });
  },
  createLoan: (token, loan) => request("/loans/", { method: "POST", token, body: loan }),
  reviewLoan: (token, id, data) => request(`/loans/${id}`, { method: "PATCH", token, body: data }),
  returnLoan: (token, id) => request(`/loans/${id}/return`, { method: "POST", token }),
  checkOverdue: (token) => request("/loans/check-overdue", { method: "POST", token }),

  getPosts: (bookTag) => {
    const qs = bookTag ? `?book_tag=${encodeURIComponent(bookTag)}` : "";
    return request(`/community/posts${qs}`);
  },
  createPost: (token, post) => request("/community/posts", { method: "POST", token, body: post }),
  updatePost: (token, id, post) => request(`/community/posts/${id}`, { method: "PATCH", token, body: post }),
  deletePost: (token, id) => request(`/community/posts/${id}`, { method: "DELETE", token }),
  likePost: (token, id) => request(`/community/posts/${id}/like`, { method: "POST", token }),
  getComments: (postId) => request(`/community/posts/${postId}/comments`),
  createComment: (token, postId, comment) =>
    request(`/community/posts/${postId}/comments`, { method: "POST", token, body: comment }),
  deleteComment: (token, postId, commentId) =>
    request(`/community/posts/${postId}/comments/${commentId}`, { method: "DELETE", token }),

  getStats: (token) => request("/admin/stats", { token }),
  getUsers: (token, role) => {
    const qs = role ? `?role=${encodeURIComponent(role)}` : "";
    return request(`/admin/users${qs}`, { token });
  },
  updateUser: (token, uid, data) => request(`/admin/users/${uid}`, { method: "PATCH", token, body: data }),
  deleteUser: (token, uid) => request(`/admin/users/${uid}`, { method: "DELETE", token }),
  getPurchases: (token) => request("/admin/purchases/my", { token }),
  createPurchase: (token, purchase) => request("/admin/purchases", { method: "POST", token, body: purchase }),
  getSettings: (token) => request("/admin/settings", { token }),
  updateSettings: (token, data) => request("/admin/settings", { method: "PATCH", token, body: data }),
};
