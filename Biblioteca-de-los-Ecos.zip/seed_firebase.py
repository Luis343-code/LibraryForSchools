"""
scripts/seed_firebase.py
─────────────────────────────────────────────────────────────────────────────
Poblado inicial de Firestore con libros, un admin y un estudiante de prueba.

Uso:
    cd bibliotheca/
    python scripts/seed_firebase.py

Requiere que .env esté configurado con FIREBASE_SERVICE_ACCOUNT_PATH.
─────────────────────────────────────────────────────────────────────────────
"""

import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from datetime import datetime, timezone
from backend.config import db, firebase_auth, get_settings
from backend.middleware.auth import set_user_role_claim
import uuid

settings = get_settings()

# ─── Datos de libros ──────────────────────────────────────────────────────────

BOOKS = [
    dict(title="El Señor de los Anillos", author="J.R.R. Tolkien",
         publisher="Allen & Unwin", year=1954, category="Fantasía",
         cover_color="#1E3A1E", book_type="both",
         total_copies=5, available_copies=3, digital_price=9.99, rating=4.9,
         synopsis="En las verdes praderas de la Comarca, el hobbit Frodo Bolsón hereda el Anillo Único forjado por Sauron. Junto a la Compañía del Anillo, emprende el viaje más peligroso de la Tierra Media. Una épica de amistad, sacrificio y la eterna lucha entre luz y sombras que redefinió el género fantástico para siempre."),
    dict(title="Harry Potter y la Piedra Filosofal", author="J.K. Rowling",
         publisher="Bloomsbury", year=1997, category="Fantasía",
         cover_color="#3A1A2E", book_type="both",
         total_copies=4, available_copies=2, digital_price=7.99, rating=4.8,
         synopsis="Un niño del cuarto de los armarios descubre que es mago. Hogwarts, quidditch, la Capa de Invisibilidad y un villano sin nariz aguardan al joven Harry Potter en esta historia que transformó la literatura juvenil y capturó generaciones enteras de lectores."),
    dict(title="1984", author="George Orwell",
         publisher="Secker & Warburg", year=1949, category="Distopía",
         cover_color="#141428", book_type="both",
         total_copies=3, available_copies=1, digital_price=6.99, rating=4.7,
         synopsis="El Gran Hermano te observa. En el estado totalitario de Oceanía, Winston Smith intenta preservar su humanidad mientras reescribe la historia para el Partido. Un retrato escalofriante sobre el poder absoluto, la vigilancia y la destrucción del pensamiento libre."),
    dict(title="Cien Años de Soledad", author="Gabriel García Márquez",
         publisher="Sudamericana", year=1967, category="Realismo Mágico",
         cover_color="#2E1A0A", book_type="physical",
         total_copies=3, available_copies=2, digital_price=8.49, rating=4.8,
         synopsis="Durante siete generaciones, la familia Buendía habita el mítico Macondo, donde llueven mariposas amarillas y los muertos caminan. La cumbre del realismo mágico latinoamericano. Premio Nobel. Una obra que transciende toda categoría literaria conocida."),
    dict(title="Dune", author="Frank Herbert",
         publisher="Chilton Books", year=1965, category="Ciencia Ficción",
         cover_color="#2E200A", book_type="both",
         total_copies=3, available_copies=0, digital_price=9.49, rating=4.7,
         synopsis="En el planeta desértico de Arrakis, única fuente de la especia más valiosa del universo, el joven Paul Atreides descubre su destino. Una epopeya de política, ecología y poder que definió la ciencia ficción moderna. Los gusanos de arena aguardan."),
    dict(title="El Hobbit", author="J.R.R. Tolkien",
         publisher="Allen & Unwin", year=1937, category="Fantasía",
         cover_color="#0E2A18", book_type="both",
         total_copies=6, available_copies=4, digital_price=7.49, rating=4.8,
         synopsis="Bilbo Bolsón, amante de la comodidad, es arrastrado por Gandalf y trece enanos en una aventura para recobrar el tesoro del dragón Smaug. Una historia sobre el coraje que descubrimos en nosotros mismos cuando creíamos no tener ninguno."),
    dict(title="Fahrenheit 451", author="Ray Bradbury",
         publisher="Ballantine Books", year=1953, category="Distopía",
         cover_color="#2E0E0A", book_type="both",
         total_copies=4, available_copies=3, digital_price=6.49, rating=4.6,
         synopsis="En un futuro donde los libros son ilegales y los bomberos los queman, Guy Montag comienza a leer en secreto. Un ardiente manifiesto sobre el valor de la literatura y el peligro de una sociedad que prefiere el entretenimiento a la verdad."),
    dict(title="El Nombre de la Rosa", author="Umberto Eco",
         publisher="Bompiani", year=1980, category="Misterio Histórico",
         cover_color="#1E1008", book_type="physical",
         total_copies=3, available_copies=2, digital_price=8.99, rating=4.5,
         synopsis="En una abadía medieval italiana, el monje Guillermo de Baskerville investiga misteriosas muertes ligadas a un libro prohibido. Donde la teología, la semiótica y el thriller se entrelazan en un laberinto de conocimiento y oscuridad. La biblioteca es el crimen."),
    dict(title="La Sombra del Viento", author="Carlos Ruiz Zafón",
         publisher="Planeta", year=2001, category="Misterio",
         cover_color="#12182A", book_type="physical",
         total_copies=2, available_copies=1, digital_price=8.49, rating=4.7,
         synopsis="En la Barcelona de posguerra, Daniel descubre en el Cementerio de los Libros Olvidados una novela del misterioso Julián Carax. Al buscar sus obras, alguien las quema una a una. Un amor apasionado a los libros y a la ciudad más literaria de España."),
    dict(title="Don Quijote de la Mancha", author="Miguel de Cervantes",
         publisher="Francisco de Robles", year=1605, category="Clásico",
         cover_color="#2A1E08", book_type="both",
         total_copies=7, available_copies=5, digital_price=7.99, rating=4.7,
         synopsis="Un hidalgo manchego enloquecido por las novelas de caballería decide ser caballero andante. Junto a Sancho Panza, emprende hazañas que confunden realidad y fantasía. La primera novela moderna y la más grande broma sobre el idealismo humano jamás escrita."),
    dict(title="El Principito", author="Antoine de Saint-Exupéry",
         publisher="Reynal & Hitchcock", year=1943, category="Clásico",
         cover_color="#0A1A2E", book_type="both",
         total_copies=8, available_copies=6, digital_price=5.49, rating=4.9,
         synopsis="Un aviador perdido en el desierto conoce a un pequeño príncipe de un asteroide lejano. A través de sus reflexiones sobre la amistad, el amor y la pérdida, descubrimos lo que hace a las cosas verdaderamente importantes. Lo esencial es invisible a los ojos."),
    dict(title="El Retrato de Dorian Gray", author="Oscar Wilde",
         publisher="Ward Lock", year=1890, category="Clásico",
         cover_color="#18122A", book_type="both",
         total_copies=4, available_copies=3, digital_price=5.99, rating=4.5,
         synopsis="Dorian Gray desea que su retrato envejezca en su lugar. Su deseo se cumple, y mientras él permanece eternamente joven, el cuadro registra cada pecado de su alma corrompida. La fábula definitiva sobre la vanidad, la corrupción y el precio de la belleza eterna."),
    dict(title="Fundación", author="Isaac Asimov",
         publisher="Gnome Press", year=1951, category="Ciencia Ficción",
         cover_color="#080E1E", book_type="both",
         total_copies=3, available_copies=2, digital_price=7.99, rating=4.6,
         synopsis="El matemático Hari Seldon predice la caída del Imperio Galáctico mediante la psicohistoria y trabaja para reducir milenios de barbarie. Una monumental obra sobre civilización, conocimiento y el poder de la ciencia aplicada al destino de la humanidad."),
    dict(title="Brave New World", author="Aldous Huxley",
         publisher="Chatto & Windus", year=1932, category="Distopía",
         cover_color="#1A1A0E", book_type="both",
         total_copies=3, available_copies=2, digital_price=6.99, rating=4.5,
         synopsis="En el año 632 d.F., el mundo es feliz por condicionamiento y drogas. Cuando un 'salvaje' del exterior llega al paraíso perfecto, la realidad de la utopía se desmenuza. La distopía del placer es más aterradora que la del dolor."),
    dict(title="Ender's Game", author="Orson Scott Card",
         publisher="Tor Books", year=1985, category="Ciencia Ficción",
         cover_color="#0A181A", book_type="both",
         total_copies=4, available_copies=3, digital_price=7.49, rating=4.6,
         synopsis="El joven genio Ender Wiggin es reclutado para una escuela de batalla espacial para convertirse en el comandante que salve a la humanidad. Una reflexión sobre la guerra, la ética del poder y el precio terrible que paga el genio cuando es instrumentalizado."),
    dict(title="Neuromancer", author="William Gibson",
         publisher="Ace Books", year=1984, category="Ciencia Ficción",
         cover_color="#060E18", book_type="physical",
         total_copies=2, available_copies=1, digital_price=8.99, rating=4.4,
         synopsis="El hacker Case es contratado para el mayor golpe en el ciberespacio. La novela que fundó el cyberpunk y definió nuestro imaginario digital décadas antes de que internet existiera tal como lo conocemos. El ciberespacio: una alucinación consensual."),
]

# ─── Usuarios de prueba ───────────────────────────────────────────────────────

TEST_USERS = [
    dict(email="admin@biblioteca.edu",     password="Admin1234!", name="Archimago Zephyr", role="admin"),
    dict(email="librarian@biblioteca.edu", password="Custodio1!", name="Archivista Aldric", role="librarian"),
    dict(email="student@biblioteca.edu",   password="Lector123!",  name="Elena Beaumont",   role="student"),
]

# ─── Posts de comunidad de ejemplo ───────────────────────────────────────────

SAMPLE_POSTS = [
    dict(user_name="Elena Beaumont",  user_avatar_initial="E",
         content="Acabo de terminar Dune por tercera vez y cada lectura revela nuevas capas. La ecología de Arrakis como metáfora política es simplemente magistral.",
         book_tag="Dune", likes=12),
    dict(user_name="Archimago Zephyr", user_avatar_initial="Z",
         content="Propuesta: leer en paralelo 1984 y Brave New World. Orwell nos habla del miedo al dolor; Huxley, al placer. Las dos grandes visiones del totalitarismo moderno.",
         book_tag="1984", likes=8),
]


# ─── Funciones de seed ────────────────────────────────────────────────────────

def seed_books():
    print("\n📚 Sembrando libros…")
    now = datetime.now(timezone.utc)
    for book in BOOKS:
        book_id = str(uuid.uuid4())
        data = {
            **book,
            "id":         book_id,
            "cover_url":  None,
            "created_at": now,
            "updated_at": now,
        }
        db.collection("books").document(book_id).set(data)
        print(f"  ✓ {book['title']}")
    print(f"  → {len(BOOKS)} libros añadidos.")


def seed_users():
    print("\n👤 Creando usuarios de prueba…")
    now = datetime.now(timezone.utc)

    for u in TEST_USERS:
        # Verificar si ya existe
        try:
            fb_user = firebase_auth.get_user_by_email(u["email"])
            print(f"  ~ {u['email']} ya existe, actualizando…")
        except firebase_auth.UserNotFoundError:
            fb_user = firebase_auth.create_user(
                email=u["email"],
                password=u["password"],
                display_name=u["name"],
            )
            print(f"  ✓ {u['email']} creado")

        # Custom claim de rol
        set_user_role_claim(fb_user.uid, u["role"])

        # Perfil en Firestore
        db.collection("users").document(fb_user.uid).set({
            "uid":         fb_user.uid,
            "name":        u["name"],
            "email":       u["email"],
            "role":        u["role"],
            "active":      True,
            "loans_count": 0,
            "created_at":  now,
            "updated_at":  now,
        })

    print(f"  → {len(TEST_USERS)} usuarios listos.")
    print("\n  Credenciales:")
    for u in TEST_USERS:
        print(f"    [{u['role']:10}]  {u['email']}  /  {u['password']}")


def seed_community():
    print("\n🌐 Sembrando posts de comunidad…")
    now = datetime.now(timezone.utc)
    for post in SAMPLE_POSTS:
        post_id = str(uuid.uuid4())
        db.collection("community_posts").document(post_id).set({
            "id":                  post_id,
            "user_id":             "seed",
            "user_name":           post["user_name"],
            "user_avatar_initial": post["user_avatar_initial"],
            "content":             post["content"],
            "book_tag":            post.get("book_tag"),
            "likes":               post.get("likes", 0),
            "comment_count":       0,
            "hidden":              False,
            "created_at":          now,
            "updated_at":          now,
        })
        print(f"  ✓ Post de {post['user_name']}")


if __name__ == "__main__":
    print("╔══════════════════════════════════════════╗")
    print("║  Bibliotheca Arcana — Seed de Firebase   ║")
    print("╚══════════════════════════════════════════╝")

    seed_books()
    seed_users()
    seed_community()

    print("\n✦ Seed completado. El Sistema Arcano está listo para su primera invocación.")
