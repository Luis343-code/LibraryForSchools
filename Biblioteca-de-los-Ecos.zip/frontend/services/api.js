const API_URL = import.meta.env.VITE_API_URL || "http://localhost:8000/api/v1";

async function request(path, { method = "GET", token, body, headers = {} } = {}) {
  const response = await fetch(`${API_URL}${path}`, {
    method,
    headers: {
      ...(body instanceof FormData ? {} : { "Content-Type": "application/json" }),
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
      ...headers,
    },
    body: body instanceof FormData ? body : body ? JSON.stringify(body) : undefined,
  });

  if (!response.ok) {
    const errorText = await response.text();
    throw new Error(errorText || `HTTP ${response.status}`);
  }

  return response.json();
}

export const api = {
  health: () => request("/health"),
  me: (token) => request("/auth/me", { token }),
  books: (params = {}) => {
    const qs = new URLSearchParams(params).toString();
    return request(`/books/${qs ? `?${qs}` : ""}`);
  },
  createLoan: (token, body) => request("/loans/", { method: "POST", token, body }),
  communityPosts: (params = {}) => {
    const qs = new URLSearchParams(params).toString();
    return request(`/community/posts${qs ? `?${qs}` : ""}`);
  },
};
