import { useState } from "react";
import "./App.css";
import { BookOpen, Search, Star, Clock, Users, BarChart2, Plus, Check, X, MessageSquare, ShoppingCart, LogOut, Crown, Edit, Trash2, Heart, Send, Bell, Shield, AlertTriangle, Scroll, Eye, Package, ChevronRight, Settings } from "lucide-react";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from "recharts";
import gandalfImg from './assets/YouShallNotPass.png';
import { initializeApp } from "firebase/app";
import { getAnalytics } from "firebase/analytics";


const BOOKS = [
  {id:1,title:"El Señor de los Anillos",author:"J.R.R. Tolkien",category:"Fantasía",year:1954,available:3,total:5,color:"#1E3A1E",type:"both",rating:4.9,price:9.99,synopsis:"En las verdes praderas de la Comarca, el hobbit Frodo Bolsón hereda el Anillo Único forjado por Sauron. Junto a la Compañía del Anillo, emprende el viaje más peligroso de la Tierra Media. Una épica de amistad, sacrificio y la eterna lucha entre luz y sombras que redefinió el género fantástico para siempre."},
  {id:2,title:"Harry Potter y la Piedra Filosofal",author:"J.K. Rowling",category:"Fantasía",year:1997,available:2,total:4,color:"#3A1A2E",type:"both",rating:4.8,price:7.99,synopsis:"Un niño del cuarto de los armarios descubre que es mago. Hogwarts, quidditch, la Capa de Invisibilidad y un villano sin nariz aguardan al joven Harry Potter en esta historia que transformó la literatura juvenil y capturó generaciones enteras de lectores."},
  {id:3,title:"1984",author:"George Orwell",category:"Distopía",year:1949,available:1,total:3,color:"#141428",type:"both",rating:4.7,price:6.99,synopsis:"El Gran Hermano te observa. En el estado totalitario de Oceanía, Winston Smith intenta preservar su humanidad mientras reescribe la historia para el Partido. Un retrato escalofriante sobre el poder absoluto, la vigilancia y la destrucción del pensamiento libre."},
  {id:4,title:"Cien Años de Soledad",author:"Gabriel García Márquez",category:"Realismo Mágico",year:1967,available:2,total:3,color:"#2E1A0A",type:"physical",rating:4.8,price:8.49,synopsis:"Durante siete generaciones, la familia Buendía habita el mítico Macondo, donde llueven mariposas amarillas y los muertos caminan. La cumbre del realismo mágico latinoamericano. Premio Nobel. Una obra que transciende toda categoría literaria conocida."},
  {id:5,title:"Dune",author:"Frank Herbert",category:"Ciencia Ficción",year:1965,available:0,total:3,color:"#2E200A",type:"both",rating:4.7,price:9.49,synopsis:"En el planeta desértico de Arrakis, única fuente de la especia más valiosa del universo, el joven Paul Atreides descubre su destino. Una epopeya de política, ecología y poder que definió la ciencia ficción moderna. Los gusanos de arena aguardan."},
  {id:6,title:"El Hobbit",author:"J.R.R. Tolkien",category:"Fantasía",year:1937,available:4,total:6,color:"#0E2A18",type:"both",rating:4.8,price:7.49,synopsis:"Bilbo Bolsón, amante de la comodidad, es arrastrado por Gandalf y trece enanos en una aventura para recobrar el tesoro del dragón Smaug. Una historia sobre el coraje que descubrimos en nosotros mismos cuando creíamos no tener ninguno."},
  {id:7,title:"Fahrenheit 451",author:"Ray Bradbury",category:"Distopía",year:1953,available:3,total:4,color:"#2E0E0A",type:"both",rating:4.6,price:6.49,synopsis:"En un futuro donde los libros son ilegales y los bomberos los queman, Guy Montag comienza a leer en secreto. Un ardiente manifiesto sobre el valor de la literatura y el peligro de una sociedad que prefiere el entretenimiento a la verdad."},
  {id:8,title:"El Nombre de la Rosa",author:"Umberto Eco",category:"Misterio Histórico",year:1980,available:2,total:3,color:"#1E1008",type:"physical",rating:4.5,price:8.99,synopsis:"En una abadía medieval italiana, el monje Guillermo de Baskerville investiga misteriosas muertes ligadas a un libro prohibido. Donde la teología, la semiótica y el thriller se entrelazan en un laberinto de conocimiento y oscuridad. La biblioteca es el crimen."},
  {id:9,title:"La Sombra del Viento",author:"Carlos Ruiz Zafón",category:"Misterio",year:2001,available:1,total:2,color:"#12182A",type:"physical",rating:4.7,price:8.49,synopsis:"En la Barcelona de posguerra, Daniel descubre en el Cementerio de los Libros Olvidados una novela del misterioso Julián Carax. Al buscar sus obras, alguien las quema una a una. Un amor apasionado a los libros y a la ciudad más literaria de España."},
  {id:10,title:"Don Quijote de la Mancha",author:"Miguel de Cervantes",category:"Clásico",year:1605,available:5,total:7,color:"#2A1E08",type:"both",rating:4.7,price:7.99,synopsis:"Un hidalgo manchego enloquecido por las novelas de caballería decide ser caballero andante. Junto a Sancho Panza, emprende hazañas que confunden realidad y fantasía. La primera novela moderna y la más grande broma sobre el idealismo humano jamás escrita."},
  {id:11,title:"El Principito",author:"Antoine de Saint-Exupéry",category:"Clásico",year:1943,available:6,total:8,color:"#0A1A2E",type:"both",rating:4.9,price:5.49,synopsis:"Un aviador perdido en el desierto conoce a un pequeño príncipe de un asteroide lejano. A través de sus reflexiones sobre la amistad, el amor y la pérdida, descubrimos lo que hace a las cosas verdaderamente importantes. Lo esencial es invisible a los ojos."},
  {id:12,title:"El Retrato de Dorian Gray",author:"Oscar Wilde",category:"Clásico",year:1890,available:3,total:4,color:"#18122A",type:"both",rating:4.5,price:5.99,synopsis:"Dorian Gray desea que su retrato envejezca en su lugar. Su deseo se cumple, y mientras él permanece eternamente joven, el cuadro registra cada pecado de su alma corrompida. La fábula definitiva sobre la vanidad, la corrupción y el precio de la belleza eterna."},
  {id:13,title:"Fundación",author:"Isaac Asimov",category:"Ciencia Ficción",year:1951,available:2,total:3,color:"#080E1E",type:"both",rating:4.6,price:7.99,synopsis:"El matemático Hari Seldon predice la caída del Imperio Galáctico mediante la psicohistoria y trabaja para reducir milenios de barbarie. Una monumental obra sobre civilización, conocimiento y el poder de la ciencia aplicada al destino de la humanidad."},
  {id:14,title:"Neuromancer",author:"William Gibson",category:"Ciencia Ficción",year:1984,available:1,total:2,color:"#060E18",type:"physical",rating:4.4,price:8.99,synopsis:"El hacker Case es contratado para el mayor golpe en el ciberespacio. La novela que fundó el cyberpunk y definió nuestro imaginario digital décadas antes de que internet existiera tal como lo conocemos. El cyberespacio: una alucinación consensual."},
  {id:15,title:"Ender's Game",author:"Orson Scott Card",category:"Ciencia Ficción",year:1985,available:3,total:4,color:"#0A181A",type:"both",rating:4.6,price:7.49,synopsis:"El joven genio Ender Wiggin es reclutado para una escuela de batalla espacial donde debe convertirse en el comandante que salve a la humanidad. Una reflexión sobre la guerra, la ética del poder y el precio terrible que paga el genio cuando es instrumentalizado."},
  {id:16,title:"Brave New World",author:"Aldous Huxley",category:"Distopía",year:1932,available:2,total:3,color:"#1A1A0E",type:"both",rating:4.5,price:6.99,synopsis:"En el año 632 d.F. (después de Ford), el mundo es feliz por condicionamiento y drogas. Cuando un 'salvaje' del exterior llega al paraíso perfecto, la realidad de la utopía se desmenuza. La distopía del placer es más aterradora que la del dolor."},
];

const INIT_LOANS = [
  {id:1,userId:1,bookId:6,bookTitle:"El Hobbit",bookAuthor:"J.R.R. Tolkien",bookColor:"#0E2A18",loanDate:"2025-04-01",dueDate:"2025-04-22",status:"active"},
  {id:2,userId:1,bookId:9,bookTitle:"La Sombra del Viento",bookAuthor:"Carlos Ruiz Zafón",bookColor:"#12182A",loanDate:"2025-03-15",dueDate:"2025-04-05",status:"overdue"},
  {id:3,userId:4,bookId:1,bookTitle:"El Señor de los Anillos",bookAuthor:"J.R.R. Tolkien",bookColor:"#1E3A1E",loanDate:"2025-04-14",dueDate:"2025-05-04",status:"pending"},
  {id:4,userId:5,bookId:3,bookTitle:"1984",bookAuthor:"George Orwell",bookColor:"#141428",loanDate:"2025-04-12",dueDate:"2025-05-02",status:"active"},
  {id:5,userId:6,bookId:7,bookTitle:"Fahrenheit 451",bookAuthor:"Ray Bradbury",bookColor:"#2E0E0A",loanDate:"2025-04-03",dueDate:"2025-04-13",status:"overdue"},
  {id:6,userId:7,bookId:11,bookTitle:"El Principito",bookAuthor:"Antoine de Saint-Exupéry",bookColor:"#0A1A2E",loanDate:"2025-04-15",dueDate:"2025-05-05",status:"pending"},
];

const INIT_POSTS = [
  {id:1,userId:1,user:"Elena Beaumont",avatar:"E",content:"Acabo de terminar Dune por tercera vez y cada lectura revela nuevas capas. La ecología de Arrakis como metáfora política es simplemente magistral. ¿Alguien más ha notado las referencias al mundo árabe en la cultura Fremen?",bookTag:"Dune",likes:24,liked:false,comments:8,time:"hace 2 horas"},
  {id:2,userId:3,user:"Archimago Zephyr",avatar:"Z",content:"Propuesta para el club: leer en paralelo 1984 y Brave New World. Orwell nos habla del miedo al dolor; Huxley, al placer. Son las dos grandes visiones del totalitarismo moderno y juntas forman el mapa más preciso de los riesgos del siglo XXI.",bookTag:"1984",likes:18,liked:false,comments:12,time:"hace 4 horas"},
  {id:3,userId:5,user:"Marcos Delgado",avatar:"M",content:"Pregunta filosófica: ¿Es Don Quijote un loco o el único cuerdo en un mundo que olvidó soñar? Cervantes escribió lo que pensó era una parodia y terminó creando el manifiesto del idealismo humano. Qué irónica belleza la de los accidentes literarios.",bookTag:"Don Quijote",likes:31,liked:false,comments:15,time:"hace 1 día"},
  {id:4,userId:6,user:"Sofía Reyes",avatar:"S",content:"El Principito me rompió el corazón de nuevo esta noche. 'Lo esencial es invisible a los ojos' es quizás la frase más poderosa de toda la literatura universal. La leí de niña sin entenderla del todo. Ahora, de adulta, me aplasta.",bookTag:"El Principito",likes:45,liked:false,comments:20,time:"hace 2 días"},
];

const USERS_LIST = [
  {id:1,name:"Elena Beaumont",email:"student@library.edu",role:"student",loans:2,joined:"2024-09-01"},
  {id:2,name:"Archivista Aldric",email:"librarian@library.edu",role:"librarian",loans:0,joined:"2024-01-15"},
  {id:3,name:"Archimago Zephyr",email:"admin@library.edu",role:"admin",loans:0,joined:"2023-08-01"},
  {id:4,name:"Marcos Delgado",email:"marcos@library.edu",role:"student",loans:1,joined:"2024-09-01"},
  {id:5,name:"Sofía Reyes",email:"sofia@library.edu",role:"student",loans:3,joined:"2024-09-01"},
  {id:6,name:"Lucas Montoya",email:"lucas@library.edu",role:"student",loans:0,joined:"2024-09-15"},
  {id:7,name:"Ana Turing",email:"ana@library.edu",role:"student",loans:1,joined:"2024-10-01"},
];

const MOCK_USERS = [
  {id:1,name:"Elena Beaumont",role:"student",email:"student@library.edu",password:"student",roleLabel:"Aprendiz de Letras"},
  {id:2,name:"Archivista Aldric",role:"librarian",email:"librarian@library.edu",password:"librarian",roleLabel:"Custodio de Volúmenes"},
  {id:3,name:"Archimago Zephyr",role:"admin",email:"admin@library.edu",password:"admin",roleLabel:"Archimago del Sistema"},
];

const CHART_COLORS = ["#C8A951","#2D6A4F","#1E3A8A","#8B1A1A","#3D2C1E"];

function Notif({msg,onDone}) {
  useEffect(()=>{const t=setTimeout(onDone,3100);return()=>clearTimeout(t);},[]);
  return <div className="notif">📜 {msg}</div>;
}

function GandalfModal({onClose}) {
  return (
    <div className="goverlay" onClick={onClose}>
      <div className="gbox" onClick={e=>e.stopPropagation()}>
        <div className="gart">
          <img src={gandalfImg} alt="Failed to load Gandalf's image" width="300px"/>
        </div>
        <div className="gquote">YOU SHALL NOT PASS!</div>
        <div className="gsub">…sin las credenciales correctas, viajero.</div>
        <br/>
        <div style={{color:"var(--parch2)",fontSize:"14px",fontStyle:"italic",lineHeight:1.6}}>
          "Tres anillos para los Reyes Elfos, uno para el bibliotecario oscuro en su sala de servidores…"
          <br/>pero ninguno para quien escribe mal su contraseña.
        </div>
        <button className="gclose" onClick={onClose}>Volver a intentarlo ✦</button>
      </div>
    </div>
  );
}

function LoginScreen({onLogin}) {
  const [email,setEmail]=useState("");
  const [pass,setPass]=useState("");
  const [showG,setShowG]=useState(false);
  const fill=(u)=>{setEmail(u.email);setPass(u.password);}
  const handleLogin=()=>{
    const u=MOCK_USERS.find(x=>x.email===email&&x.password===pass);
    if(u)onLogin(u); else setShowG(true);
  };
  return (
    <div className="lbg">
      {showG&&<GandalfModal onClose={()=>setShowG(false)}/>}
      <div className="lcard">
        <div className="llogo">
          <div style={{fontSize:"44px",marginBottom:"8px"}}>📚</div>
          <div className="ltitle">La Biblioteca de los Ecos</div>
          <div className="lsub">"Un libro es un sueño que tienes en tus manos" — Neil Gaiman</div>
        </div>
        <div className="lfield">
          <label>Pergamino de Identidad</label>
          <input value={email} onChange={e=>setEmail(e.target.value)} placeholder="tu.nombre@biblioteca.edu" onKeyDown={e=>e.key==='Enter'&&handleLogin()}/>
        </div>
        <div className="lfield">
          <label>Contraseña de los Ecos</label>
          <input type="password" value={pass} onChange={e=>setPass(e.target.value)} placeholder="••••••••••" onKeyDown={e=>e.key==='Enter'&&handleLogin()}/>
        </div>
        <button className="lbtn" onClick={handleLogin}>✦ Invocar Acceso ✦</button>
        <div className="ldemo">
          <div className="ldemo-t">Portales de Demostración</div>
          {MOCK_USERS.map(u=>(
            <div key={u.id} className="ldemo-row" onClick={()=>fill(u)}>
              <span className="ldemo-role">{u.roleLabel}</span>
              <span className="ldemo-creds">{u.email} / {u.password}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function BookCover({book,mini=false}) {
  const sz=mini?{width:58,height:78,borderRadius:6,fontSize:9}:{width:130,height:188,borderRadius:8,fontSize:11};
  return (
    <div style={{background:book.color||book.bookColor||"#1A2A1A",width:sz.width,height:sz.height,borderRadius:sz.borderRadius,flexShrink:0,display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",padding:8}}>
      {!mini&&<div style={{fontFamily:"'Cinzel',serif",fontSize:sz.fontSize,textAlign:"center",color:"rgba(255,255,255,.92)",fontWeight:600,lineHeight:1.4,textShadow:"0 2px 4px rgba(0,0,0,.5)"}}>{book.title||book.bookTitle}</div>}
    </div>
  );
}

function Sidebar({role,page,setPage,user,onLogout}) {
  const studentMenu=[
    {id:"catalog",icon:<BookCoverIcon/>,label:"Catálogo",ico:"📚"},
    {id:"loans",icon:null,label:"Mis Préstamos",ico:"📋"},
    {id:"store",icon:null,label:"Tienda Digital",ico:"🛒"},
    {id:"community",icon:null,label:"Comunidad",ico:"🌐"},
  ];
  const libMenu=[
    {id:"books",label:"Gestión de Libros",ico:"📖"},
    {id:"loanmgmt",label:"Préstamos",ico:"📦"},
    {id:"community",label:"Comunidad",ico:"🌐"},
  ];
  const adminMenu=[
    {id:"dashboard",label:"Dashboard",ico:"📊"},
    {id:"users",label:"Usuarios",ico:"👥"},
    {id:"settings",label:"Configuración",ico:"⚙️"},
  ];
  const menus={student:studentMenu,librarian:libMenu,admin:adminMenu};
  const roleLabels={student:"Aprendiz de Letras",librarian:"Custodio de Volúmenes",admin:"Archimago del Sistema"};
  return (
    <div className="sidebar">
      <div className="slogo">
        <div style={{fontSize:"22px",marginBottom:"4px"}}>📚</div>
        <div className="slogo-t">BIBLIOTECA</div>
        <div className="slogo-s">De los Ecos · Est. MMXXV</div>
      </div>
      <div className="ssec">
        <div className="ssec-l">Navegación</div>
        {(menus[role]||[]).map(item=>(
          <div key={item.id} className={`sitem${page===item.id?" active":""}`} onClick={()=>setPage(item.id)}>
            <span style={{fontSize:"15px"}}>{item.ico}</span>
            <span>{item.label}</span>
          </div>
        ))}
      </div>
      <div className="suser">
        <div style={{display:"flex",alignItems:"center",gap:"10px",marginBottom:"8px"}}>
          <div style={{width:36,height:36,borderRadius:"50%",background:"var(--green2)",display:"flex",alignItems:"center",justifyContent:"center",fontFamily:"'Cinzel',serif",fontSize:14,color:"var(--parch)",flexShrink:0,fontWeight:600}}>{user.name[0]}</div>
          <div>
            <div className="suser-n">{user.name}</div>
            <div className="suser-r">{roleLabels[role]}</div>
          </div>
        </div>
        <div className="slogout" onClick={onLogout}>
          <LogOut size={14}/> Cerrar Sesión
        </div>
      </div>
    </div>
  );
}

function BookCoverIcon(){return null;}

// ─── STUDENT APP ────────────────────────────────────────────────────────────
function StudentApp({user,onLogout}) {
  const [page,setPage]=useState("catalog");
  const [loans,setLoans]=useState(INIT_LOANS.filter(l=>l.userId===1));
  const [posts,setPosts]=useState(INIT_POSTS);
  const [notif,setNotif]=useState(null);
  const [selected,setSelected]=useState(null);
  const [search,setSearch]=useState("");
  const [catFilter,setCatFilter]=useState("Todas");
  const [newPost,setNewPost]=useState("");
  const [purchased,setPurchased]=useState([]);

  const showNotif=(m)=>{setNotif(m);};
  const categories=["Todas",...[...new Set(BOOKS.map(b=>b.category))]];
  const filtered=BOOKS.filter(b=>(catFilter==="Todas"||b.category===catFilter)&&(b.title.toLowerCase().includes(search.toLowerCase())||b.author.toLowerCase().includes(search.toLowerCase())));
  const availLabel=(b)=>b.available===0?"Sin ejemplares":b.available<=1?"Último ejemplar":`${b.available} disponibles`;
  const availClass=(b)=>b.available===0?"no":b.available<=1?"low":"ok";

  const requestLoan=(book)=>{
    if(book.available===0){showNotif("Este volumen ha partido a tierras lejanas. No hay ejemplares disponibles.");return;}
    const already=loans.find(l=>l.bookId===book.id&&l.status!=="returned");
    if(already){showNotif("Ya tienes este grimorio en tu poder, sabio lector.");return;}
    const due=new Date();due.setDate(due.getDate()+21);
    setLoans(prev=>[...prev,{id:Date.now(),userId:1,bookId:book.id,bookTitle:book.title,bookAuthor:book.author,bookColor:book.color,loanDate:new Date().toISOString().split("T")[0],dueDate:due.toISOString().split("T")[0],status:"pending"}]);
    showNotif(`"${book.title}" ha sido convocado. El bibliotecario revisará tu solicitud.`);
    setSelected(null);
  };

  const buyBook=(book)=>{
    if(purchased.includes(book.id)){showNotif("Este volumen ya forma parte de tu biblioteca digital.");return;}
    setPurchased(prev=>[...prev,book.id]);
    showNotif(`"${book.title}" ha sido añadido a tu biblioteca digital. ¡Feliz lectura!`);
  };

  const toggleLike=(id)=>{
    setPosts(prev=>prev.map(p=>p.id===id?{...p,liked:!p.liked,likes:p.liked?p.likes-1:p.likes+1}:p));
  };

  const submitPost=()=>{
    if(!newPost.trim())return;
    setPosts(prev=>[{id:Date.now(),userId:1,user:user.name,avatar:user.name[0],content:newPost,bookTag:null,likes:0,liked:false,comments:0,time:"ahora mismo"},...prev]);
    setNewPost("");
    showNotif("Tu pensamiento ha sido grabado en los Anales de la Comunidad.");
  };

  const statusLabel=(s)=>({active:"Activo",overdue:"Vencido",pending:"Pendiente",returned:"Devuelto"}[s]||s);
  const statusClass=(s)=>({active:"chip-a",overdue:"chip-o",pending:"chip-p",returned:"chip-r"}[s]||"chip-p");

  return (
    <div className="app">
      {notif&&<Notif msg={notif} onDone={()=>setNotif(null)}/>}
      {selected&&(
        <div className="movl" onClick={()=>setSelected(null)}>
          <div className="modal" onClick={e=>e.stopPropagation()}>
            <button className="mclose" onClick={()=>setSelected(null)}><X size={18}/></button>
            <div className="mhdr">
              <div className="mcover" style={{background:selected.color}}><div className="mcover-t">{selected.title}</div></div>
              <div className="minfo">
                <div className="mtitle">{selected.title}</div>
                <div className="mauthor">{selected.author}</div>
                <div className="mmeta">
                  <span className="mtag">{selected.category}</span>
                  <span className="mtag">{selected.year}</span>
                  <span className="mtag">★ {selected.rating}</span>
                  {selected.type==="both"&&<span className="mtag btype-b">Físico + Digital</span>}
                  {selected.type==="physical"&&<span className="mtag btype-p">Solo Físico</span>}
                </div>
                <div style={{marginTop:"14px",display:"flex",alignItems:"center",gap:"8px"}}>
                  <span style={{fontFamily:"'Cinzel',serif",fontSize:"11px",color:"var(--muted)"}}>EJEMPLARES:</span>
                  <span className={`bavail ${availClass(selected)}`}>{availLabel(selected)}</span>
                </div>
              </div>
            </div>
            <div className="mbody">
              <div className="mstitle">Sinopsis</div>
              <div className="msynopsis">{selected.synopsis}</div>
              <div className="macts">
                {selected.available>0&&<button className="btn btn-g" onClick={()=>requestLoan(selected)}>📋 Solicitar Préstamo</button>}
                {(selected.type==="both"||selected.type==="digital")&&<button className="btn btn-o" onClick={()=>{buyBook(selected);setSelected(null);}}>🛒 Comprar Digital — ${selected.price}</button>}
                <button className="btn btn-o" onClick={()=>setSelected(null)}>Cerrar</button>
              </div>
            </div>
          </div>
        </div>
      )}
      <Sidebar role="student" page={page} setPage={setPage} user={user} onLogout={onLogout}/>
      <div className="main">
        {page==="catalog"&&(
          <div className="page">
            <div className="ph">
              <div className="ptitle">📚 Catálogo de Volúmenes</div>
              <div className="psub">"Una habitación sin libros es como un cuerpo sin alma." — Marco Tulio Cicerón</div>
            </div>
            <div className="sbar">
              <div className="sinp-w"><Search size={15} style={{position:"absolute",left:11,top:"50%",transform:"translateY(-50%)",color:"var(--muted)"}}/><input className="sinp" placeholder="Buscar por título o autor…" value={search} onChange={e=>setSearch(e.target.value)}/></div>
              <select className="fsel" value={catFilter} onChange={e=>setCatFilter(e.target.value)}>
                {categories.map(c=><option key={c}>{c}</option>)}
              </select>
            </div>
            <div className="bgrid">
              {filtered.map(book=>(
                <div key={book.id} className="bcard" onClick={()=>setSelected(book)}>
                  <div className="bcover" style={{background:book.color}}>
                    <div className="bcover-t">{book.title}</div>
                    <div className="bcover-a">{book.author}</div>
                    <span className={`btype ${book.type==="both"?"btype-b":book.type==="physical"?"btype-p":"btype-d"}`}>{book.type==="both"?"F+D":book.type==="physical"?"Físico":"Digital"}</span>
                  </div>
                  <div className="binfo">
                    <div className="bcat">{book.category}</div>
                    <div className="bmeta">
                      <div className="brat"><Star size={11}/>  {book.rating}</div>
                      <div className={`bavail ${availClass(book)}`}>{availLabel(book)}</div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
            {filtered.length===0&&<div className="empty-state"><div className="es-icon">🔍</div><p>Ningún volumen coincide con tu búsqueda arcana</p></div>}
          </div>
        )}
        {page==="loans"&&(
          <div className="page">
            <div className="ph">
              <div className="ptitle">📋 Mis Préstamos</div>
              <div className="psub">"Los libros prestados son deudas del alma." — Anónimo sabio</div>
            </div>
            {loans.length===0&&<div className="empty-state"><div className="es-icon">📭</div><p>Tu estantería está vacía. Explora el catálogo e invoca tus primeros volúmenes</p></div>}
            {loans.map(loan=>(
              <div key={loan.id} className="lcard2">
                <BookCover book={loan} mini/>
                <div className="li">
                  <div className="li-t">{loan.bookTitle}</div>
                  <div className="li-a">{loan.bookAuthor}</div>
                  <div className="li-s">
                    <span className={`chip ${statusClass(loan.status)}`}>{statusLabel(loan.status)}</span>
                    {loan.status!=="returned"&&loan.status!=="pending"&&(
                      <span style={{display:"flex",alignItems:"center",gap:5,fontSize:13,color:loan.status==="overdue"?"var(--red2)":"var(--parch2)"}}>
                        <Clock size={12}/> Devolver: {loan.dueDate}
                      </span>
                    )}
                    {loan.status==="pending"&&<span style={{fontSize:13,color:"var(--muted)",fontStyle:"italic"}}>Esperando aprobación del Custodio…</span>}
                    {loan.status==="overdue"&&<span style={{fontSize:13,color:"var(--red2)",fontStyle:"italic"}}>⚠ Este volumen ha excedido su tiempo en tierras prestadas</span>}
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
        {page==="store"&&(
          <div className="page">
            <div className="ph">
              <div className="ptitle">🛒 Tienda Digital</div>
              <div className="psub">"Los libros son el plano de vuelo del pensamiento." — Proverbio arcano</div>
            </div>
            <div className="sgrid">
              {BOOKS.filter(b=>b.type==="both").map(book=>(
                <div key={book.id} className="scard">
                  <div className="scover" style={{background:book.color}}>
                    <div style={{fontFamily:"'Cinzel',serif",fontSize:11,textAlign:"center",color:"rgba(255,255,255,.9)",fontWeight:600,lineHeight:1.4}}>{book.title}</div>
                    <div style={{fontSize:10,color:"rgba(255,255,255,.6)",marginTop:4,fontStyle:"italic"}}>{book.author}</div>
                  </div>
                  <div className="sinfo">
                    <div className="stitle">{book.title}</div>
                    <div style={{display:"flex",alignItems:"baseline",gap:6,marginTop:6}}>
                      <span className="sprice">${book.price}</span>
                      <span className="sprice-o">${(book.price*1.3).toFixed(2)}</span>
                    </div>
                    <button className="btn btn-g" style={{width:"100%",marginTop:10,padding:"8px"}} onClick={()=>buyBook(book)}>
                      {purchased.includes(book.id)?"✓ En tu Biblioteca":"🛒 Adquirir"}
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
        {page==="community"&&(
          <div className="page">
            <div className="ph">
              <div className="ptitle">🌐 Comunidad Literaria</div>
              <div className="psub">"Compartir un libro es multiplicar un alma." — Los Anales de la Biblioteca</div>
            </div>
            <div className="pinp-w">
              <textarea className="pinp" rows={2} placeholder="Comparte tus reflexiones, debates, recomendaciones… El saber compartido ilumina más que el saber guardado." value={newPost} onChange={e=>setNewPost(e.target.value)}/>
              <button className="btn btn-g" style={{alignSelf:"flex-end",padding:"11px 18px"}} onClick={submitPost}><Send size={14}/></button>
            </div>
            {posts.map(post=>(
              <div key={post.id} className="post">
                <div className="phdr2">
                  <div className="pavt">{post.avatar}</div>
                  <div><div className="pun">{post.user}</div><div className="ptm">{post.time}</div></div>
                  {post.bookTag&&<div className="pbtag">📖 {post.bookTag}</div>}
                </div>
                <div className="pcont">{post.content}</div>
                <div className="pacts">
                  <button className={`pact${post.liked?" liked":""}`} onClick={()=>toggleLike(post.id)}><Heart size={13}/> {post.likes}</button>
                  <button className="pact"><MessageSquare size={13}/> {post.comments} comentarios</button>
                  <button className="pact"><ChevronRight size={13}/> Compartir</button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

// ─── LIBRARIAN APP ──────────────────────────────────────────────────────────
function LibrarianApp({user,onLogout}) {
  const [page,setPage]=useState("loanmgmt");
  const [loans,setLoans]=useState(INIT_LOANS);
  const [books,setBooks]=useState(BOOKS);
  const [posts,setPosts]=useState(INIT_POSTS);
  const [notif,setNotif]=useState(null);
  const [showAddBook,setShowAddBook]=useState(false);
  const [newBook,setNewBook]=useState({title:"",author:"",category:"",year:"",available:"",total:"",synopsis:"",type:"both",price:""});

  const showNotif=(m)=>setNotif(m);
  const approveLoan=(id)=>{setLoans(p=>p.map(l=>l.id===id?{...l,status:"active"}:l));showNotif("Préstamo aprobado. El volumen ha partido hacia su nuevo hogar temporal.");};
  const denyLoan=(id)=>{setLoans(p=>p.map(l=>l.id===id?{...l,status:"denied"}:l));showNotif("Solicitud denegada. El lector ha sido notificado.");};
  const markReturned=(id)=>{setLoans(p=>p.map(l=>l.id===id?{...l,status:"returned"}:l));showNotif("Devolución registrada. El volumen ha vuelto a los estantes.");};
  const deleteBook=(id)=>{setBooks(p=>p.filter(b=>b.id!==id));showNotif("El volumen ha sido removido del catálogo.");};
  const deletePost=(id)=>{setPosts(p=>p.filter(p=>p.id!==id));showNotif("Publicación removida por el Custodio.");};
  const addBook=()=>{
    if(!newBook.title||!newBook.author)return;
    setBooks(p=>[...p,{...newBook,id:Date.now(),available:parseInt(newBook.available)||1,total:parseInt(newBook.total)||1,rating:4.0,color:"#1A2A1A",year:parseInt(newBook.year)||2024}]);
    setNewBook({title:"",author:"",category:"",year:"",available:"",total:"",synopsis:"",type:"both",price:""});
    setShowAddBook(false);
    showNotif("Nuevo volumen añadido al catálogo arcano.");
  };

  const statusLabel=(s)=>({active:"Activo",overdue:"Vencido",pending:"Pendiente",returned:"Devuelto",denied:"Denegado"}[s]||s);
  const statusClass=(s)=>({active:"chip-a",overdue:"chip-o",pending:"chip-p",returned:"chip-r",denied:"chip-o"}[s]);

  return (
    <div className="app">
      {notif&&<Notif msg={notif} onDone={()=>setNotif(null)}/>}
      <Sidebar role="librarian" page={page} setPage={setPage} user={user} onLogout={onLogout}/>
      <div className="main">
        {page==="loanmgmt"&&(
          <div className="page">
            <div className="ph">
              <div className="ptitle">📦 Gestión de Préstamos</div>
              <div className="psub">Supervisión de los volúmenes que viajan por el mundo</div>
            </div>
            <div className="tab-bar" style={{marginBottom:22}}>
              <div style={{padding:"7px 14px",fontFamily:"'Cinzel',serif",fontSize:11,color:"var(--gold)"}}>
                Pendientes: {loans.filter(l=>l.status==="pending").length} · Activos: {loans.filter(l=>l.status==="active").length} · Vencidos: {loans.filter(l=>l.status==="overdue").length}
              </div>
            </div>
            <div style={{overflowX:"auto"}}>
            <table className="dtable">
              <thead><tr><th>Volumen</th><th>Lector</th><th>F. Préstamo</th><th>F. Devolución</th><th>Estado</th><th>Acciones</th></tr></thead>
              <tbody>
                {loans.filter(l=>l.status!=="denied").map(loan=>(
                  <tr key={loan.id}>
                    <td><div style={{fontFamily:"'Cinzel',serif",fontSize:13,color:"var(--gold)"}}>{loan.bookTitle}</div><div style={{fontSize:12,color:"var(--muted)",fontStyle:"italic"}}>{loan.bookAuthor}</div></td>
                    <td>Lector #{loan.userId}</td>
                    <td>{loan.loanDate}</td>
                    <td style={{color:loan.status==="overdue"?"var(--red2)":"inherit"}}>{loan.dueDate}</td>
                    <td><span className={`chip ${statusClass(loan.status)}`}>{statusLabel(loan.status)}</span></td>
                    <td>
                      {loan.status==="pending"&&<><button className="abtn abtn-a" onClick={()=>approveLoan(loan.id)}>✓ Aprobar</button><button className="abtn abtn-d" onClick={()=>denyLoan(loan.id)}>✕ Denegar</button></>}
                      {(loan.status==="active"||loan.status==="overdue")&&<button className="abtn abtn-e" onClick={()=>markReturned(loan.id)}>↩ Devuelto</button>}
                      {loan.status==="returned"&&<span style={{fontSize:12,color:"var(--muted)"}}>Completado</span>}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
            </div>
          </div>
        )}
        {page==="books"&&(
          <div className="page">
            <div className="ph">
              <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start"}}>
                <div><div className="ptitle">📖 Gestión de Libros</div><div className="psub">El catálogo bajo tu custodia, Guardián de Volúmenes</div></div>
                <button className="btn btn-g" onClick={()=>setShowAddBook(!showAddBook)}><Plus size={13}/> Añadir Volumen</button>
              </div>
            </div>
            {showAddBook&&(
              <div className="addbk-form">
                <div style={{fontFamily:"'Cinzel',serif",fontSize:13,color:"var(--gold)",marginBottom:16}}>✦ Registrar Nuevo Volumen</div>
                <div className="addbk-grid">
                  <div className="ff"><label>Título</label><input value={newBook.title} onChange={e=>setNewBook(p=>({...p,title:e.target.value}))} placeholder="El nombre del libro"/></div>
                  <div className="ff"><label>Autor</label><input value={newBook.author} onChange={e=>setNewBook(p=>({...p,author:e.target.value}))} placeholder="Nombre del autor"/></div>
                  <div className="ff"><label>Categoría</label><input value={newBook.category} onChange={e=>setNewBook(p=>({...p,category:e.target.value}))} placeholder="Fantasía, Ciencia Ficción…"/></div>
                  <div className="ff"><label>Año</label><input value={newBook.year} onChange={e=>setNewBook(p=>({...p,year:e.target.value}))} placeholder="1984"/></div>
                  <div className="ff"><label>Disponibles</label><input value={newBook.available} onChange={e=>setNewBook(p=>({...p,available:e.target.value}))} placeholder="3"/></div>
                  <div className="ff"><label>Total</label><input value={newBook.total} onChange={e=>setNewBook(p=>({...p,total:e.target.value}))} placeholder="5"/></div>
                  <div className="ff"><label>Tipo</label><select value={newBook.type} onChange={e=>setNewBook(p=>({...p,type:e.target.value}))}><option value="both">Físico + Digital</option><option value="physical">Solo Físico</option><option value="digital">Solo Digital</option></select></div>
                  <div className="ff"><label>Precio Digital ($)</label><input value={newBook.price} onChange={e=>setNewBook(p=>({...p,price:e.target.value}))} placeholder="9.99"/></div>
                  <div className="ff" style={{gridColumn:"1/-1"}}><label>Sinopsis</label><textarea value={newBook.synopsis} onChange={e=>setNewBook(p=>({...p,synopsis:e.target.value}))} placeholder="Describe los misterios que guarda este volumen…"/></div>
                </div>
                <div style={{display:"flex",gap:10,marginTop:16}}>
                  <button className="btn btn-g" onClick={addBook}>✦ Añadir al Catálogo</button>
                  <button className="btn btn-o" onClick={()=>setShowAddBook(false)}>Cancelar</button>
                </div>
              </div>
            )}
            <div style={{overflowX:"auto"}}>
            <table className="dtable">
              <thead><tr><th>Título</th><th>Autor</th><th>Categoría</th><th>Disponibles</th><th>Tipo</th><th>Acciones</th></tr></thead>
              <tbody>
                {books.map(b=>(
                  <tr key={b.id}>
                    <td style={{fontFamily:"'Cinzel',serif",color:"var(--gold)",fontSize:13}}>{b.title}</td>
                    <td style={{fontStyle:"italic"}}>{b.author}</td>
                    <td>{b.category}</td>
                    <td><span className={`bavail ${b.available===0?"no":b.available<=1?"low":"ok"}`}>{b.available}/{b.total}</span></td>
                    <td><span className={`btype ${b.type==="both"?"btype-b":b.type==="physical"?"btype-p":"btype-d"}`}>{b.type==="both"?"F+D":b.type==="physical"?"Fís":"Dig"}</span></td>
                    <td><button className="abtn abtn-e"><Edit size={10}/></button><button className="abtn abtn-d" onClick={()=>deleteBook(b.id)}><Trash2 size={10}/></button></td>
                  </tr>
                ))}
              </tbody>
            </table>
            </div>
          </div>
        )}
        {page==="community"&&(
          <div className="page">
            <div className="ph">
              <div className="ptitle">🌐 Moderación de Comunidad</div>
              <div className="psub">Guardando la paz en los Anales Literarios</div>
            </div>
            {posts.map(post=>(
              <div key={post.id} className="post">
                <div className="phdr2">
                  <div className="pavt">{post.avatar}</div>
                  <div><div className="pun">{post.user}</div><div className="ptm">{post.time}</div></div>
                  {post.bookTag&&<div className="pbtag">📖 {post.bookTag}</div>}
                  <button className="abtn abtn-d" style={{marginLeft:"auto"}} onClick={()=>deletePost(post.id)}><Trash2 size={10}/> Eliminar</button>
                </div>
                <div className="pcont">{post.content}</div>
                <div className="pacts">
                  <button className="pact"><Heart size={13}/> {post.likes}</button>
                  <button className="pact"><MessageSquare size={13}/> {post.comments}</button>
                  <span style={{marginLeft:"auto",fontSize:12,color:"var(--muted)"}}>ID: #{post.userId}</span>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

// ─── ADMIN APP ───────────────────────────────────────────────────────────────
function AdminApp({user,onLogout}) {
  const [page,setPage]=useState("dashboard");
  const [users,setUsers]=useState(USERS_LIST);
  const [notif,setNotif]=useState(null);

  const loansByStatus=[
    {name:"Activos",value:INIT_LOANS.filter(l=>l.status==="active").length},
    {name:"Vencidos",value:INIT_LOANS.filter(l=>l.status==="overdue").length},
    {name:"Pendientes",value:INIT_LOANS.filter(l=>l.status==="pending").length},
  ];
  const topBooks=BOOKS.sort((a,b)=>b.rating-a.rating).slice(0,6).map(b=>({name:b.title.length>18?b.title.substring(0,18)+"…":b.title,préstamos:Math.floor(Math.random()*20)+5,rating:b.rating}));
  const monthlyData=[
    {mes:"Ene",préstamos:34},{mes:"Feb",préstamos:52},{mes:"Mar",préstamos:48},{mes:"Abr",préstamos:65},
    {mes:"May",préstamos:71},{mes:"Jun",préstamos:58},{mes:"Jul",préstamos:43},{mes:"Ago",préstamos:67},
  ];
  const catData=[...new Set(BOOKS.map(b=>b.category))].map(c=>({name:c,value:BOOKS.filter(b=>b.category===c).length}));

  const deleteUser=(id)=>{setUsers(p=>p.filter(u=>u.id!==id));setNotif("Usuario removido del registro arcano.");};
  const roleLabel=(r)=>({student:"Aprendiz",librarian:"Custodio",admin:"Archimago"}[r]||r);
  const roleClass=(r)=>({student:"role-s",librarian:"role-l",admin:"role-a"}[r]||"role-s");

  return (
    <div className="app">
      {notif&&<Notif msg={notif} onDone={()=>setNotif(null)}/>}
      <Sidebar role="admin" page={page} setPage={setPage} user={user} onLogout={onLogout}/>
      <div className="main">
        {page==="dashboard"&&(
          <div className="page">
            <div className="ph">
              <div className="ptitle">📊 Dashboard del Archimago</div>
              <div className="psub">"El conocimiento es el único tesoro que crece al compartirse." — Anónimo</div>
            </div>
            <div className="statg">
              <div className="stcard"><div className="stnum">{BOOKS.length}</div><div className="stlbl">Volúmenes en Catálogo</div><div className="sti"><BookOpen size={48}/></div></div>
              <div className="stcard"><div className="stnum">{USERS_LIST.filter(u=>u.role==="student").length}</div><div className="stlbl">Lectores Registrados</div><div className="sti"><Users size={48}/></div></div>
              <div className="stcard"><div className="stnum">{INIT_LOANS.filter(l=>l.status==="active").length}</div><div className="stlbl">Préstamos Activos</div><div className="sti"><Package size={48}/></div></div>
              <div className="stcard"><div className="stnum" style={{color:"var(--red2)"}}>{INIT_LOANS.filter(l=>l.status==="overdue").length}</div><div className="stlbl">Préstamos Vencidos</div><div className="sti" style={{color:"var(--red)"}}><AlertTriangle size={48}/></div></div>
            </div>
            <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:18,marginBottom:18}}>
              <div className="cbox">
                <div className="cbox-t">📈 Préstamos Mensuales</div>
                <ResponsiveContainer width="100%" height={200}>
                  <BarChart data={monthlyData} margin={{top:0,right:10,left:-20,bottom:0}}>
                    <XAxis dataKey="mes" tick={{fill:"#607090",fontSize:11,fontFamily:"Cinzel"}}/>
                    <YAxis tick={{fill:"#607090",fontSize:11}}/>
                    <Tooltip contentStyle={{background:"#111f3a",border:"1px solid rgba(200,169,81,.3)",borderRadius:8,color:"#F5E6C8",fontFamily:"Crimson Text"}}/>
                    <Bar dataKey="préstamos" fill="#C8A951" radius={[4,4,0,0]}/>
                  </BarChart>
                </ResponsiveContainer>
              </div>
              <div className="cbox">
                <div className="cbox-t">🗂 Libros por Categoría</div>
                <ResponsiveContainer width="100%" height={200}>
                  <PieChart>
                    <Pie data={catData} cx="50%" cy="50%" innerRadius={50} outerRadius={80} dataKey="value" nameKey="name">
                      {catData.map((_,i)=><Cell key={i} fill={CHART_COLORS[i%CHART_COLORS.length]}/>)}
                    </Pie>
                    <Tooltip contentStyle={{background:"#111f3a",border:"1px solid rgba(200,169,81,.3)",borderRadius:8,color:"#F5E6C8",fontFamily:"Crimson Text"}}/>
                  </PieChart>
                </ResponsiveContainer>
              </div>
            </div>
            <div className="cbox">
              <div className="cbox-t">⭐ Volúmenes Más Venerados (por calificación)</div>
              <ResponsiveContainer width="100%" height={180}>
                <BarChart data={topBooks} layout="vertical" margin={{top:0,right:10,left:10,bottom:0}}>
                  <XAxis type="number" domain={[0,25]} tick={{fill:"#607090",fontSize:10}}/>
                  <YAxis type="category" dataKey="name" width={140} tick={{fill:"#C8A951",fontSize:10,fontFamily:"Cinzel"}}/>
                  <Tooltip contentStyle={{background:"#111f3a",border:"1px solid rgba(200,169,81,.3)",borderRadius:8,color:"#F5E6C8",fontFamily:"Crimson Text"}}/>
                  <Bar dataKey="préstamos" fill="#2D6A4F" radius={[0,4,4,0]}/>
                </BarChart>
              </ResponsiveContainer>
            </div>
            <div className="cbox">
              <div className="cbox-t">⚖ Estado de Préstamos</div>
              <div style={{display:"flex",gap:16}}>
                {loansByStatus.map((s,i)=>(
                  <div key={i} style={{background:"var(--card2)",borderRadius:8,padding:"14px 20px",flex:1,textAlign:"center"}}>
                    <div style={{fontFamily:"'Cinzel',serif",fontSize:28,color:["#40916C","var(--red2)","var(--gold)"][i],fontWeight:700}}>{s.value}</div>
                    <div style={{fontSize:12,color:"var(--muted)",marginTop:4}}>{s.name}</div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}
        {page==="users"&&(
          <div className="page">
            <div className="ph">
              <div className="ptitle">👥 Gestión de Usuarios</div>
              <div className="psub">Los lectores que habitan la biblioteca de los ecos</div>
            </div>
            <div style={{overflowX:"auto"}}>
            <table className="dtable">
              <thead><tr><th>Lector</th><th>Correo</th><th>Rol</th><th>Préstamos</th><th>Se unió</th><th>Acciones</th></tr></thead>
              <tbody>
                {users.map(u=>(
                  <tr key={u.id}>
                    <td>
                      <div style={{display:"flex",alignItems:"center",gap:10}}>
                        <div style={{width:32,height:32,borderRadius:"50%",background:"var(--green2)",display:"flex",alignItems:"center",justifyContent:"center",fontFamily:"'Cinzel',serif",fontSize:13,color:"var(--parch)",fontWeight:600,flexShrink:0}}>{u.name[0]}</div>
                        <span style={{fontFamily:"'Cinzel',serif",fontSize:13,color:"var(--gold)"}}>{u.name}</span>
                      </div>
                    </td>
                    <td style={{fontSize:13}}>{u.email}</td>
                    <td><span className={`badge-role ${roleClass(u.role)}`}>{roleLabel(u.role)}</span></td>
                    <td>{u.loans}</td>
                    <td style={{fontSize:13,color:"var(--muted)"}}>{u.joined}</td>
                    <td>
                      <button className="abtn abtn-e"><Eye size={10}/></button>
                      {u.role!=="admin"&&<button className="abtn abtn-d" onClick={()=>deleteUser(u.id)}><Trash2 size={10}/></button>}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
            </div>
          </div>
        )}
        {page==="settings"&&(
          <div className="page">
            <div className="ph">
              <div className="ptitle">⚙️ Configuración</div>
              <div className="psub">Los pergaminos de configuración del sistema arcano</div>
            </div>
            {[
              ["Nombre de la Biblioteca","La Biblioteca de los Ecos — Sistema Escolar"],
              ["Días de préstamo por defecto","21 días"],
              ["Límite de préstamos por lector","3 volúmenes simultáneos"],
              ["Penalización por retraso","1 día de espera por día de retraso"],
              ["Notificaciones de vencimiento","5 días antes de la fecha límite"],
            ].map(([label,val])=>(
              <div key={label} className="cbox" style={{display:"flex",justifyContent:"space-between",alignItems:"center",padding:"16px 22px",marginBottom:10}}>
                <div>
                  <div style={{fontFamily:"'Cinzel',serif",fontSize:13,color:"var(--parch)"}}>{label}</div>
                  <div style={{fontSize:13,color:"var(--muted)",marginTop:3,fontStyle:"italic"}}>{val}</div>
                </div>
                <button className="abtn abtn-e"><Edit size={10}/> Editar</button>
              </div>
            ))}
            <div className="ornament">✦ ✧ ✦</div>
            <div style={{textAlign:"center",color:"var(--muted)",fontSize:14,fontStyle:"italic"}}>
              "En el principio fue el Verbo, y el Verbo fue hecho libro." — Versión de los Ecos
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

export default function App() {

  const [user,setUser]=useState(null);
  if(!user)return <LoginScreen onLogin={setUser}/>;
  if(user.role==="student")return <StudentApp user={user} onLogout={()=>setUser(null)}/>;
  if(user.role==="librarian")return <LibrarianApp user={user} onLogout={()=>setUser(null)}/>;
  if(user.role==="admin")return <AdminApp user={user} onLogout={()=>setUser(null)}/>;
}

// const app = initializeApp(firebaseConfig);