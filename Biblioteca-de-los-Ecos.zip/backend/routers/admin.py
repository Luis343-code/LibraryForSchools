from __future__ import annotations

from uuid import uuid4
from fastapi import APIRouter, Depends
from backend.middleware.auth import CurrentUser, require_role

router = APIRouter(prefix="/admin", tags=["admin"])


@router.get("/stats", dependencies=[Depends(require_role("admin"))])
def stats():
    return {"books": 0, "loans": 0, "community_posts": 0, "purchases": 0}


@router.get("/users", dependencies=[Depends(require_role("admin"))])
def list_users():
    return {"items": []}


@router.patch("/users/{uid}", dependencies=[Depends(require_role("admin"))])
def update_user(uid: str):
    return {"uid": uid, "message": "Usuario actualizado."}


@router.delete("/users/{uid}", dependencies=[Depends(require_role("admin"))])
def delete_user(uid: str):
    return {"uid": uid, "message": "Usuario eliminado."}


@router.post("/purchases", dependencies=[Depends(require_role("admin"))])
def create_purchase():
    return {"id": str(uuid4()), "message": "Compra registrada."}


@router.get("/purchases/my")
def my_purchases(user: CurrentUser = Depends(require_role("student", "librarian", "admin"))):
    return {"user_id": user.uid, "items": []}
