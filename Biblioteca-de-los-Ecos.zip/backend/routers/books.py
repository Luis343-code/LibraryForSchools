from __future__ import annotations

from uuid import uuid4
from fastapi import APIRouter, Depends, Query
from backend.middleware.auth import CurrentUser, require_role

router = APIRouter(prefix="/books", tags=["books"])

SAMPLE_CATEGORIES = ["Fantasía", "Aventura", "Historia", "Ciencia", "Distopía", "Clásicos"]


@router.get("/")
def list_books(
    search: str | None = Query(default=None),
    category: str | None = Query(default=None),
    available: bool | None = Query(default=None),
    book_type: str | None = Query(default=None),
):
    return {"items": [], "filters": {"search": search, "category": category, "available": available, "book_type": book_type}}


@router.post("/", dependencies=[Depends(require_role("librarian", "admin"))])
def create_book():
    return {"id": str(uuid4()), "message": "Libro creado (stub)."}


@router.get("/{book_id}")
def get_book(book_id: str):
    return {"id": book_id, "title": "Libro de ejemplo"}


@router.patch("/{book_id}", dependencies=[Depends(require_role("librarian", "admin"))])
def update_book(book_id: str):
    return {"id": book_id, "message": "Libro actualizado (stub)."}


@router.delete("/{book_id}", dependencies=[Depends(require_role("librarian", "admin"))])
def delete_book(book_id: str):
    return {"id": book_id, "message": "Libro eliminado (stub)."}


@router.post("/{book_id}/cover", dependencies=[Depends(require_role("librarian", "admin"))])
def upload_cover(book_id: str):
    return {"id": book_id, "message": "Portada cargada (stub)."}


@router.get("/meta/categories")
def categories():
    return {"items": SAMPLE_CATEGORIES}
