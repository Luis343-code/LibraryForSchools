from __future__ import annotations

from datetime import datetime, timedelta
from uuid import uuid4

from fastapi import APIRouter, Depends, Query
from backend.middleware.auth import CurrentUser, require_role

router = APIRouter(prefix="/loans", tags=["loans"])


@router.get("/")
def list_loans(status: str | None = Query(default=None), user: CurrentUser = Depends(require_role("student", "librarian", "admin"))):
    return {"items": [], "status": status, "viewer": user.role}


@router.post("/")
def create_loan(user: CurrentUser = Depends(require_role("student", "librarian", "admin"))):
    return {"id": str(uuid4()), "status": "pending", "requested_by": user.uid}


@router.patch("/{loan_id}", dependencies=[Depends(require_role("librarian", "admin"))])
def review_loan(loan_id: str):
    return {"id": loan_id, "message": "Solicitud revisada (approve/deny)."}


@router.post("/{loan_id}/return", dependencies=[Depends(require_role("librarian", "admin"))])
def return_loan(loan_id: str):
    return {"id": loan_id, "returned_at": datetime.utcnow().isoformat(), "message": "Libro devuelto."}


@router.post("/check-overdue", dependencies=[Depends(require_role("admin"))])
def check_overdue():
    return {"checked_at": datetime.utcnow().isoformat(), "overdue_count": 0, "window": str(timedelta(days=1))}
