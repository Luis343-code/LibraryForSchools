from __future__ import annotations

from fastapi import APIRouter, Depends
from backend.middleware.auth import CurrentUser, get_current_user

router = APIRouter(prefix="/auth", tags=["auth"])


@router.post("/register")
def register():
    return {"message": "Registro pendiente de integrar con Firebase Auth."}


@router.get("/me")
def me(user: CurrentUser = Depends(get_current_user)):
    return {"uid": user.uid, "role": user.role, "email": user.email, "name": "Usuario demo"}


@router.patch("/me")
def update_me():
    return {"message": "Actualización de perfil pendiente."}


@router.post("/logout")
def logout():
    return {"message": "Sesión cerrada."}
