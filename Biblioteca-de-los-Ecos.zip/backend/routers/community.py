from __future__ import annotations

from uuid import uuid4
from fastapi import APIRouter, Depends, Query
from backend.middleware.auth import CurrentUser, require_role

router = APIRouter(prefix="/community", tags=["community"])


@router.get("/posts")
def list_posts(book_tag: str | None = Query(default=None)):
    return {"items": [], "book_tag": book_tag}


@router.post("/posts")
def create_post(user: CurrentUser = Depends(require_role("student", "librarian", "admin"))):
    return {"id": str(uuid4()), "user_id": user.uid, "message": "Publicación creada."}


@router.patch("/posts/{post_id}")
def update_post(post_id: str):
    return {"id": post_id, "message": "Publicación editada."}


@router.delete("/posts/{post_id}")
def delete_post(post_id: str):
    return {"id": post_id, "message": "Publicación eliminada."}


@router.post("/posts/{post_id}/like")
def like_post(post_id: str):
    return {"id": post_id, "message": "Like registrado."}


@router.get("/posts/{post_id}/comments")
def list_comments(post_id: str):
    return {"post_id": post_id, "items": []}


@router.post("/posts/{post_id}/comments")
def create_comment(post_id: str):
    return {"post_id": post_id, "id": str(uuid4()), "message": "Comentario agregado."}


@router.delete("/posts/{post_id}/comments/{cid}")
def delete_comment(post_id: str, cid: str):
    return {"post_id": post_id, "comment_id": cid, "message": "Comentario eliminado."}
