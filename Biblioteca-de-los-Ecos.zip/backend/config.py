from __future__ import annotations

import os
from functools import lru_cache
from pathlib import Path
from typing import Optional

from dotenv import load_dotenv
from firebase_admin import credentials, firestore, initialize_app, auth as firebase_auth
from pydantic_settings import BaseSettings, SettingsConfigDict

load_dotenv()


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    firebase_service_account_path: str = os.getenv("FIREBASE_SERVICE_ACCOUNT_PATH", "./firebase/serviceAccountKey.json")
    firebase_project_id: str = os.getenv("FIREBASE_PROJECT_ID", "biblioteca-de-los-ecos")
    firebase_storage_bucket: str = os.getenv("FIREBASE_STORAGE_BUCKET", "biblioteca-de-los-ecos.appspot.com")
    firebase_database_url: Optional[str] = os.getenv("FIREBASE_DATABASE_URL")
    firebase_app_name: str = os.getenv("FIREBASE_APP_NAME", "Biblioteca de los Ecos")


@lru_cache
def get_settings() -> Settings:
    return Settings()


def init_firebase():
    settings = get_settings()
    service_account_path = Path(settings.firebase_service_account_path)

    if not service_account_path.exists():
        return None

    try:
        initialize_app(
            credentials.Certificate(str(service_account_path)),
            {
                "projectId": settings.firebase_project_id,
                "storageBucket": settings.firebase_storage_bucket,
                **({"databaseURL": settings.firebase_database_url} if settings.firebase_database_url else {}),
            },
            name=settings.firebase_app_name,
        )
    except ValueError:
        # App already initialized.
        pass

    return firestore.client()


db = init_firebase()
