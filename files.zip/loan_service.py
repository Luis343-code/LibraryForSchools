from sqlalchemy.orm import Session
from fastapi import HTTPException
from datetime import date, timedelta
from decimal import Decimal
from app.models.loan import Loan, LoanPolicy
from app.models.book import Copy
from app.models.report import DisciplinaryReport
from app.schemas.loan import LoanCreate, ReturnRequest

def create_loan(db: Session, data: LoanCreate, staff_id: int) -> Loan:
    copy = db.query(Copy).filter(Copy.copy_id == data.copy_id).first()
    if not copy or copy.status != "available":
        raise HTTPException(status_code=400, detail="Copia no disponible para préstamo")
    policy = db.query(LoanPolicy).filter(LoanPolicy.policy_id == data.policy_id).first()
    if not policy:
        raise HTTPException(status_code=404, detail="Política de préstamo no encontrada")
    today = date.today()
    loan = Loan(
        copy_id=data.copy_id,
        student_id=data.student_id,
        issued_by_staff_id=staff_id,
        policy_id=data.policy_id,
        issue_date=today,
        due_date=today + timedelta(days=policy.max_loan_days),
        fine_amount=Decimal("0"),
    )
    copy.status = "loaned"
    db.add(loan)
    db.commit()
    db.refresh(loan)
    return loan

def return_loan(db: Session, data: ReturnRequest) -> Loan:
    loan = db.query(Loan).filter(Loan.loan_id == data.loan_id).first()
    if not loan:
        raise HTTPException(status_code=404, detail="Préstamo no encontrado")
    if loan.return_date:
        raise HTTPException(status_code=400, detail="Este préstamo ya fue devuelto")
    today = date.today()
    loan.return_date = today
    copy = db.query(Copy).filter(Copy.copy_id == loan.copy_id).first()
    if copy:
        copy.status = "available"
    # Calcular multa si aplica
    policy = db.query(LoanPolicy).filter(LoanPolicy.policy_id == loan.policy_id).first()
    if policy and today > loan.due_date + timedelta(days=policy.grace_days):
        days_late = (today - loan.due_date).days
        loan.fine_amount = Decimal(str(days_late)) * policy.fine_per_day
    db.commit()
    db.refresh(loan)
    return loan

def get_student_loan_history(db: Session, student_id: int) -> list:
    return db.query(Loan).filter(Loan.student_id == student_id).all()

def get_overdue_loans(db: Session) -> list:
    today = date.today()
    return db.query(Loan).filter(
        Loan.return_date.is_(None),
        Loan.due_date < today
    ).all()
