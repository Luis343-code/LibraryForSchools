# Sistema de Gestión de Librería Escolar

API REST construida con FastAPI + SQLAlchemy + PostgreSQL.

## Requisitos
- Python 3.11+
- PostgreSQL 14+

## Instalación rápida

```bash
# 1. Clonar e instalar dependencias
pip install -r requirements.txt

# 2. Configurar variables de entorno
cp .env.example .env
# Editar .env con tus credenciales de PostgreSQL

# 3. Crear la base de datos en PostgreSQL
createdb libreria_escolar

# 4. Correr migraciones
alembic upgrade head

# 5. Iniciar el servidor
uvicorn app.main:app --reload
```

## Documentación interactiva
Disponible en: http://localhost:8000/docs

## Endpoints principales

| Módulo        | Método | Ruta                            | Descripción                  |
|---------------|--------|---------------------------------|------------------------------|
| Auth          | POST   | /api/v1/auth/register           | Registrar staff              |
| Auth          | POST   | /api/v1/auth/login              | Login → JWT                  |
| Libros        | GET    | /api/v1/books                   | Catálogo paginado            |
| Libros        | POST   | /api/v1/books                   | Crear libro                  |
| Libros        | POST   | /api/v1/books/copies            | Agregar copia física         |
| Estudiantes   | GET    | /api/v1/students                | Listar estudiantes           |
| Estudiantes   | POST   | /api/v1/students                | Registrar estudiante         |
| Préstamos     | POST   | /api/v1/loans                   | Emitir préstamo              |
| Préstamos     | PUT    | /api/v1/loans/return            | Registrar devolución         |
| Préstamos     | GET    | /api/v1/loans/overdue           | Préstamos atrasados          |
| Reservaciones | POST   | /api/v1/reservations            | Crear reservación            |
| Reservaciones | DELETE | /api/v1/reservations/{id}       | Cancelar reservación         |
| Reportes      | GET    | /api/v1/reports/most-borrowed   | Libros más prestados         |
| Reportes      | GET    | /api/v1/reports/overdue-summary | Resumen de atrasos           |
| Reportes      | GET    | /api/v1/reports/inventory       | Estado del inventario        |

## Roles
- **admin** – acceso completo
- **librarian** – gestión de préstamos, catálogo y estudiantes

## Estructura del proyecto
```
libreria_escolar/
├── app/
│   ├── api/v1/endpoints/   # Routers FastAPI
│   ├── core/               # Config, JWT, dependencias
│   ├── db/                 # Sesión SQLAlchemy
│   ├── models/             # Modelos ORM (14 tablas)
│   ├── schemas/            # Pydantic schemas
│   ├── services/           # Lógica de negocio
│   └── main.py
├── alembic/                # Migraciones
├── requirements.txt
└── .env.example
```
