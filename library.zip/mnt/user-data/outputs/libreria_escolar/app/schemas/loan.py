from pydantic import BaseModel
from datetime import date
from typing import Optional
from decimal import Decimal

class LoanCreate(BaseModel):
    copy_id: int
    student_id: int
    policy_id: int

class LoanRead(BaseModel):
    loan_id: int
    copy_id: int
    student_id: int
    issue_date: date
    due_date: date
    return_date: Optional[date] = None
    fine_amount: Decimal
    model_config = {"from_attributes": True}

class ReturnRequest(BaseModel):
    loan_id: int
