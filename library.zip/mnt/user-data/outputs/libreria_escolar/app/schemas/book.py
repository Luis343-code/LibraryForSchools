from pydantic import BaseModel
from typing import Optional, List

class BookCreate(BaseModel):
    isbn: str
    title: str
    publisher_id: Optional[int] = None
    publication_year: Optional[int] = None
    language: Optional[str] = None
    subject: Optional[str] = None
    edition: Optional[str] = None
    author_ids: List[int] = []
    category_ids: List[int] = []

class BookRead(BaseModel):
    book_id: int
    isbn: str
    title: str
    publication_year: Optional[int] = None
    language: Optional[str] = None
    subject: Optional[str] = None
    edition: Optional[str] = None
    model_config = {"from_attributes": True}

class CopyCreate(BaseModel):
    book_id: int
    shelf_id: Optional[int] = None
    barcode: str
    condition: str = "good"

class CopyRead(BaseModel):
    copy_id: int
    book_id: int
    barcode: str
    condition: str
    status: str
    model_config = {"from_attributes": True}
