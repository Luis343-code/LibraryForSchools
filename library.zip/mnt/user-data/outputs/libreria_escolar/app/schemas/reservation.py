from pydantic import BaseModel
from datetime import date
from typing import Optional

class ReservationCreate(BaseModel):
    copy_id: int
    student_id: int

class ReservationRead(BaseModel):
    reservation_id: int
    copy_id: int
    student_id: int
    request_date: date
    status: str
    expires_at: Optional[date] = None
    model_config = {"from_attributes": True}
