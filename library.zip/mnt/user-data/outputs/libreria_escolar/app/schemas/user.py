from pydantic import BaseModel, EmailStr

class StudentBase(BaseModel):
    first_name: str
    last_name: str
    grade: str
    email: EmailStr

class StudentCreate(StudentBase):
    pass

class StudentRead(StudentBase):
    student_id: int
    status: str
    model_config = {"from_attributes": True}

class StaffCreate(BaseModel):
    first_name: str
    last_name: str
    role: str
    email: EmailStr
    password: str

class StaffRead(BaseModel):
    staff_id: int
    first_name: str
    last_name: str
    role: str
    email: EmailStr
    model_config = {"from_attributes": True}

class LoginRequest(BaseModel):
    email: EmailStr
    password: str
