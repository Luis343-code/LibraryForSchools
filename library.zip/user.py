from sqlalchemy import Column, Integer, String
from app.db.base import Base

class Student(Base):
    __tablename__ = "student"
    student_id = Column(Integer, primary_key=True, index=True)
    first_name = Column(String, nullable=False)
    last_name  = Column(String, nullable=False)
    grade      = Column(String)
    email      = Column(String, unique=True, index=True, nullable=False)
    status     = Column(String, default="active")  # active | suspended

class Staff(Base):
    __tablename__ = "staff"
    staff_id        = Column(Integer, primary_key=True, index=True)
    first_name      = Column(String, nullable=False)
    last_name       = Column(String, nullable=False)
    role            = Column(String, nullable=False)  # admin | librarian
    email           = Column(String, unique=True, index=True, nullable=False)
    hashed_password = Column(String, nullable=False)
