from sqlalchemy.orm import Session
from sqlalchemy import func
from datetime import date
from app.models.loan import Loan
from app.models.book import Book, Copy

def most_borrowed_books(db: Session, limit: int = 10) -> list:
    return (
        db.query(Book.title, func.count(Loan.loan_id).label("total"))
        .join(Copy, Copy.book_id == Book.book_id)
        .join(Loan, Loan.copy_id == Copy.copy_id)
        .group_by(Book.book_id)
        .order_by(func.count(Loan.loan_id).desc())
        .limit(limit)
        .all()
    )

def overdue_summary(db: Session) -> dict:
    today = date.today()
    total = db.query(Loan).filter(
        Loan.return_date.is_(None),
        Loan.due_date < today
    ).count()
    return {"overdue_loans": total, "as_of": str(today)}

def inventory_summary(db: Session) -> list:
    return (
        db.query(Copy.status, func.count(Copy.copy_id).label("total"))
        .group_by(Copy.status)
        .all()
    )
