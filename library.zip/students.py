from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List
from app.db.session import get_db
from app.schemas.user import StudentCreate, StudentRead
from app.models.user import Student
from app.core.dependencies import require_librarian_or_admin

router = APIRouter(prefix="/students", tags=["students"])

@router.post("/", response_model=StudentRead, status_code=201,
             dependencies=[Depends(require_librarian_or_admin)])
def create_student(data: StudentCreate, db: Session = Depends(get_db)):
    student = Student(**data.model_dump())
    db.add(student)
    db.commit()
    db.refresh(student)
    return student

@router.get("/", response_model=List[StudentRead],
            dependencies=[Depends(require_librarian_or_admin)])
def list_students(skip: int = 0, limit: int = 50, db: Session = Depends(get_db)):
    return db.query(Student).offset(skip).limit(limit).all()

@router.get("/{student_id}", response_model=StudentRead,
            dependencies=[Depends(require_librarian_or_admin)])
def get_student(student_id: int, db: Session = Depends(get_db)):
    s = db.query(Student).filter(Student.student_id == student_id).first()
    if not s:
        raise HTTPException(404, "Estudiante no encontrado")
    return s

@router.put("/{student_id}", response_model=StudentRead,
            dependencies=[Depends(require_librarian_or_admin)])
def update_student(student_id: int, data: StudentCreate, db: Session = Depends(get_db)):
    s = db.query(Student).filter(Student.student_id == student_id).first()
    if not s:
        raise HTTPException(404, "Estudiante no encontrado")
    for key, value in data.model_dump().items():
        setattr(s, key, value)
    db.commit()
    db.refresh(s)
    return s
