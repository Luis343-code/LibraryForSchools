from sqlalchemy import Column, Integer, String, Date, ForeignKey
from app.db.base import Base

class Publisher(Base):
    __tablename__ = "publisher"
    publisher_id = Column(Integer, primary_key=True)
    name         = Column(String, nullable=False)
    country      = Column(String)

class Author(Base):
    __tablename__ = "author"
    author_id  = Column(Integer, primary_key=True)
    first_name = Column(String, nullable=False)
    last_name  = Column(String, nullable=False)

class Category(Base):
    __tablename__ = "category"
    category_id = Column(Integer, primary_key=True)
    name        = Column(String, nullable=False, unique=True)

class Book(Base):
    __tablename__ = "book"
    book_id          = Column(Integer, primary_key=True)
    isbn             = Column(String, unique=True, nullable=False)
    title            = Column(String, nullable=False)
    publisher_id     = Column(Integer, ForeignKey("publisher.publisher_id"))
    publication_year = Column(Integer)
    language         = Column(String)
    subject          = Column(String)
    edition          = Column(String)

class BookAuthor(Base):
    __tablename__ = "bookauthor"
    book_id   = Column(Integer, ForeignKey("book.book_id"), primary_key=True)
    author_id = Column(Integer, ForeignKey("author.author_id"), primary_key=True)

class BookCategory(Base):
    __tablename__ = "bookcategory"
    book_id     = Column(Integer, ForeignKey("book.book_id"), primary_key=True)
    category_id = Column(Integer, ForeignKey("category.category_id"), primary_key=True)

class Shelf(Base):
    __tablename__ = "shelf"
    shelf_id    = Column(Integer, primary_key=True)
    code        = Column(String, nullable=False, unique=True)
    description = Column(String)

class Copy(Base):
    __tablename__ = "copy"
    copy_id          = Column(Integer, primary_key=True)
    book_id          = Column(Integer, ForeignKey("book.book_id"), nullable=False)
    shelf_id         = Column(Integer, ForeignKey("shelf.shelf_id"))
    barcode          = Column(String, unique=True, nullable=False)
    acquisition_date = Column(Date)
    condition        = Column(String)   # new | good | fair | poor
    status           = Column(String, default="available")  # available | loaned | reserved | lost

class InventorySnapshot(Base):
    __tablename__ = "inventory_snapshot"
    inventory_id = Column(Integer, primary_key=True)
    book_id      = Column(Integer, ForeignKey("book.book_id"), nullable=False)
    status       = Column(String)
    quantity     = Column(Integer)
    as_of_date   = Column(Date)
