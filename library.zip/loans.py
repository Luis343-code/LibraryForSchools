from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from typing import List
from app.db.session import get_db
from app.schemas.loan import LoanCreate, LoanRead, ReturnRequest
from app.services.loan_service import create_loan, return_loan, get_student_loan_history, get_overdue_loans
from app.core.dependencies import require_librarian_or_admin, get_current_staff
from app.models.user import Staff

router = APIRouter(prefix="/loans", tags=["loans"])

@router.post("/", response_model=LoanRead, status_code=201)
def issue_loan(
    data: LoanCreate,
    db: Session = Depends(get_db),
    staff: Staff = Depends(require_librarian_or_admin),
):
    return create_loan(db, data, staff.staff_id)

@router.put("/return", response_model=LoanRead)
def return_book(
    data: ReturnRequest,
    db: Session = Depends(get_db),
    _: Staff = Depends(require_librarian_or_admin),
):
    return return_loan(db, data)

@router.get("/overdue", response_model=List[LoanRead])
def overdue(db: Session = Depends(get_db), _: Staff = Depends(require_librarian_or_admin)):
    return get_overdue_loans(db)

@router.get("/student/{student_id}", response_model=List[LoanRead])
def student_history(
    student_id: int,
    db: Session = Depends(get_db),
    _: Staff = Depends(get_current_staff),
):
    return get_student_loan_history(db, student_id)
