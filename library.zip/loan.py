from sqlalchemy import Column, Integer, ForeignKey, Date, Numeric
from app.db.base import Base

class LoanPolicy(Base):
    __tablename__ = "loan_policy"
    policy_id                 = Column(Integer, primary_key=True)
    max_loan_days             = Column(Integer, nullable=False, default=14)
    grace_days                = Column(Integer, default=2)
    report_after_days_overdue = Column(Integer, default=7)
    fine_per_day              = Column(Numeric(10, 2), default=0.50)

class Loan(Base):
    __tablename__ = "loan"
    loan_id            = Column(Integer, primary_key=True)
    copy_id            = Column(Integer, ForeignKey("copy.copy_id"), nullable=False)
    student_id         = Column(Integer, ForeignKey("student.student_id"), nullable=False)
    issued_by_staff_id = Column(Integer, ForeignKey("staff.staff_id"), nullable=False)
    policy_id          = Column(Integer, ForeignKey("loan_policy.policy_id"), nullable=False)
    issue_date         = Column(Date, nullable=False)
    due_date           = Column(Date, nullable=False)
    return_date        = Column(Date, nullable=True)
    fine_amount        = Column(Numeric(10, 2), default=0)
