from fastapi import Depends, HTTPException, status
from fastapi.security import OAuth2PasswordBearer
from sqlalchemy.orm import Session
from jose import JWTError
from app.db.session import get_db
from app.core.security import decode_token
from app.models.user import Staff

oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/api/v1/auth/login")

def get_current_staff(
    token: str = Depends(oauth2_scheme),
    db: Session = Depends(get_db)
) -> Staff:
    credentials_exception = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Credenciales inválidas",
        headers={"WWW-Authenticate": "Bearer"},
    )
    try:
        payload = decode_token(token)
        staff_id: int = payload.get("sub")
        if staff_id is None:
            raise credentials_exception
    except JWTError:
        raise credentials_exception
    staff = db.query(Staff).filter(Staff.staff_id == int(staff_id)).first()
    if not staff:
        raise credentials_exception
    return staff

def require_admin(current_staff: Staff = Depends(get_current_staff)) -> Staff:
    if current_staff.role != "admin":
        raise HTTPException(status_code=403, detail="Se requiere rol de administrador")
    return current_staff

def require_librarian_or_admin(current_staff: Staff = Depends(get_current_staff)) -> Staff:
    if current_staff.role not in ("admin", "librarian"):
        raise HTTPException(status_code=403, detail="Acceso no autorizado")
    return current_staff
