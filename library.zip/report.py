from sqlalchemy import Column, Integer, ForeignKey, Date, String
from app.db.base import Base

class DisciplinaryReport(Base):
    __tablename__ = "disciplinary_report"
    report_id           = Column(Integer, primary_key=True)
    student_id          = Column(Integer, ForeignKey("student.student_id"), nullable=False)
    loan_id             = Column(Integer, ForeignKey("loan.loan_id"), nullable=False)
    created_by_staff_id = Column(Integer, ForeignKey("staff.staff_id"), nullable=False)
    report_date         = Column(Date, nullable=False)
    days_overdue        = Column(Integer)
    status              = Column(String)   # open | resolved
    action_taken        = Column(String)
    notes               = Column(String)
