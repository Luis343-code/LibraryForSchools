from sqlalchemy import Column, Integer, ForeignKey, Date, String
from app.db.base import Base

class Reservation(Base):
    __tablename__ = "reservation"
    reservation_id = Column(Integer, primary_key=True)
    copy_id        = Column(Integer, ForeignKey("copy.copy_id"), nullable=False)
    student_id     = Column(Integer, ForeignKey("student.student_id"), nullable=False)
    request_date   = Column(Date, nullable=False)
    status         = Column(String, default="pending")  # pending | fulfilled | expired | cancelled
    fulfilled_date = Column(Date, nullable=True)
    expires_at     = Column(Date, nullable=True)
