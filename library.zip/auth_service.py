from sqlalchemy.orm import Session
from fastapi import HTTPException, status
from app.models.user import Staff
from app.schemas.user import StaffCreate, LoginRequest
from app.schemas.token import Token
from app.core.security import hash_password, verify_password, create_access_token

def register_staff(db: Session, data: StaffCreate) -> Staff:
    if db.query(Staff).filter(Staff.email == data.email).first():
        raise HTTPException(status_code=400, detail="Email ya registrado")
    staff = Staff(
        first_name=data.first_name,
        last_name=data.last_name,
        role=data.role,
        email=data.email,
        hashed_password=hash_password(data.password),
    )
    db.add(staff)
    db.commit()
    db.refresh(staff)
    return staff

def login_staff(db: Session, data: LoginRequest) -> Token:
    staff = db.query(Staff).filter(Staff.email == data.email).first()
    if not staff or not verify_password(data.password, staff.hashed_password):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Email o contraseña incorrectos",
        )
    token = create_access_token({"sub": str(staff.staff_id), "role": staff.role})
    return Token(access_token=token)
