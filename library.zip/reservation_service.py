from sqlalchemy.orm import Session
from fastapi import HTTPException
from datetime import date, timedelta
from app.models.reservation import Reservation
from app.models.book import Copy
from app.schemas.reservation import ReservationCreate

RESERVATION_EXPIRY_DAYS = 3

def create_reservation(db: Session, data: ReservationCreate) -> Reservation:
    copy = db.query(Copy).filter(Copy.copy_id == data.copy_id).first()
    if not copy or copy.status == "available":
        raise HTTPException(status_code=400, detail="Solo se pueden reservar copias no disponibles")
    today = date.today()
    res = Reservation(
        copy_id=data.copy_id,
        student_id=data.student_id,
        request_date=today,
        expires_at=today + timedelta(days=RESERVATION_EXPIRY_DAYS),
        status="pending",
    )
    db.add(res)
    db.commit()
    db.refresh(res)
    return res

def cancel_reservation(db: Session, reservation_id: int) -> Reservation:
    res = db.query(Reservation).filter(Reservation.reservation_id == reservation_id).first()
    if not res:
        raise HTTPException(status_code=404, detail="Reservación no encontrada")
    res.status = "cancelled"
    db.commit()
    db.refresh(res)
    return res
