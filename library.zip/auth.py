from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from app.db.session import get_db
from app.schemas.user import StaffCreate, StaffRead, LoginRequest
from app.schemas.token import Token
from app.services.auth_service import register_staff, login_staff

router = APIRouter(prefix="/auth", tags=["auth"])

@router.post("/register", response_model=StaffRead, status_code=201)
def register(data: StaffCreate, db: Session = Depends(get_db)):
    """Registrar nuevo miembro del staff."""
    return register_staff(db, data)

@router.post("/login", response_model=Token)
def login(data: LoginRequest, db: Session = Depends(get_db)):
    """Iniciar sesión y obtener token JWT."""
    return login_staff(db, data)
