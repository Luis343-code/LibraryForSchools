from app.db.base import Base
from app.db.session import engine
import app.models  # importa todos los modelos

Base.metadata.create_all(bind=engine)
print("Tablas creadas correctamente")
