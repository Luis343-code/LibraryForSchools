from fastapi import APIRouter
from app.api.v1.endpoints import auth, books, loans, reservations, reports, students

api_router = APIRouter(prefix="/api/v1")
api_router.include_router(auth.router)
api_router.include_router(books.router)
api_router.include_router(loans.router)
api_router.include_router(reservations.router)
api_router.include_router(reports.router)
api_router.include_router(students.router)
