from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from typing import List
from app.db.session import get_db
from app.schemas.book import BookCreate, BookRead, CopyCreate, CopyRead
from app.services.book_service import create_book, get_books, get_book, add_copy, delete_book
from app.core.dependencies import require_librarian_or_admin

router = APIRouter(prefix="/books", tags=["books"])

@router.get("/", response_model=List[BookRead])
def list_books(skip: int = 0, limit: int = 20, db: Session = Depends(get_db)):
    return get_books(db, skip, limit)

@router.get("/{book_id}", response_model=BookRead)
def detail_book(book_id: int, db: Session = Depends(get_db)):
    return get_book(db, book_id)

@router.post("/", response_model=BookRead, status_code=201,
             dependencies=[Depends(require_librarian_or_admin)])
def create(data: BookCreate, db: Session = Depends(get_db)):
    return create_book(db, data)

@router.delete("/{book_id}", status_code=204,
               dependencies=[Depends(require_librarian_or_admin)])
def remove(book_id: int, db: Session = Depends(get_db)):
    delete_book(db, book_id)

@router.post("/copies", response_model=CopyRead, status_code=201,
             dependencies=[Depends(require_librarian_or_admin)])
def add_book_copy(data: CopyCreate, db: Session = Depends(get_db)):
    return add_copy(db, data)
