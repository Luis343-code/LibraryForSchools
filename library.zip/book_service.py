from sqlalchemy.orm import Session
from fastapi import HTTPException
from app.models.book import Book, Copy, BookAuthor, BookCategory
from app.schemas.book import BookCreate, CopyCreate

def create_book(db: Session, data: BookCreate) -> Book:
    if db.query(Book).filter(Book.isbn == data.isbn).first():
        raise HTTPException(status_code=400, detail="ISBN ya registrado")
    book = Book(
        isbn=data.isbn,
        title=data.title,
        publisher_id=data.publisher_id,
        publication_year=data.publication_year,
        language=data.language,
        subject=data.subject,
        edition=data.edition,
    )
    db.add(book)
    db.flush()
    for aid in data.author_ids:
        db.add(BookAuthor(book_id=book.book_id, author_id=aid))
    for cid in data.category_ids:
        db.add(BookCategory(book_id=book.book_id, category_id=cid))
    db.commit()
    db.refresh(book)
    return book

def get_books(db: Session, skip: int = 0, limit: int = 20) -> list:
    return db.query(Book).offset(skip).limit(limit).all()

def get_book(db: Session, book_id: int) -> Book:
    book = db.query(Book).filter(Book.book_id == book_id).first()
    if not book:
        raise HTTPException(status_code=404, detail="Libro no encontrado")
    return book

def update_book(db: Session, book_id: int, data: dict) -> Book:
    book = get_book(db, book_id)
    for key, value in data.items():
        if value is not None:
            setattr(book, key, value)
    db.commit()
    db.refresh(book)
    return book

def delete_book(db: Session, book_id: int) -> None:
    book = get_book(db, book_id)
    db.delete(book)
    db.commit()

def add_copy(db: Session, data: CopyCreate) -> Copy:
    if db.query(Copy).filter(Copy.barcode == data.barcode).first():
        raise HTTPException(status_code=400, detail="Código de barras ya existe")
    copy = Copy(**data.model_dump())
    db.add(copy)
    db.commit()
    db.refresh(copy)
    return copy
