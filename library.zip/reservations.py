from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from app.db.session import get_db
from app.schemas.reservation import ReservationCreate, ReservationRead
from app.services.reservation_service import create_reservation, cancel_reservation
from app.core.dependencies import get_current_staff

router = APIRouter(prefix="/reservations", tags=["reservations"])

@router.post("/", response_model=ReservationRead, status_code=201)
def reserve(data: ReservationCreate, db: Session = Depends(get_db), _=Depends(get_current_staff)):
    return create_reservation(db, data)

@router.delete("/{reservation_id}", response_model=ReservationRead)
def cancel(reservation_id: int, db: Session = Depends(get_db), _=Depends(get_current_staff)):
    return cancel_reservation(db, reservation_id)
