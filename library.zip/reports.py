from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from app.db.session import get_db
from app.services.report_service import most_borrowed_books, overdue_summary, inventory_summary
from app.core.dependencies import require_librarian_or_admin

router = APIRouter(prefix="/reports", tags=["reports"])

@router.get("/most-borrowed")
def top_books(limit: int = 10, db: Session = Depends(get_db), _=Depends(require_librarian_or_admin)):
    rows = most_borrowed_books(db, limit)
    return [{"title": r[0], "total_loans": r[1]} for r in rows]

@router.get("/overdue-summary")
def overdue(db: Session = Depends(get_db), _=Depends(require_librarian_or_admin)):
    return overdue_summary(db)

@router.get("/inventory")
def inventory(db: Session = Depends(get_db), _=Depends(require_librarian_or_admin)):
    rows = inventory_summary(db)
    return [{"status": r[0], "total": r[1]} for r in rows]
